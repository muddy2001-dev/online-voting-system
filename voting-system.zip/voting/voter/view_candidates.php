<?php
session_start();
include_once __DIR__ . '/../admin/database.php';

// Fetch distinct positions
$positions = [];
$result = $conn->query("SELECT DISTINCT position FROM candidates");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $positions[] = $row['position'];
    }
}

$selected_position = $_POST['position'] ?? '';
$candidates = [];
if ($selected_position) {
    $stmt = $conn->prepare("SELECT * FROM candidates WHERE position = ?");
    $stmt->bind_param("s", $selected_position);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $candidates[] = $row;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Candidates</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: #f4f4f4;
    margin: 0;
    padding: 20px;
}
.container {
    max-width: 900px;
    margin: auto;
    background: #fff;
    border-radius: 12px;
    padding: 30px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
}
h2 {
    text-align: center;
    color: #007bff;
}
form {
    margin-bottom: 30px;
    text-align: center;
}
select {
    padding: 10px 15px;
    font-size: 1rem;
    border-radius: 8px;
    border: 1px solid #ccc;
}
.candidates {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: center;
}
.candidate-card {
    background: #fff;
    border-radius: 12px;
    padding: 15px;
    width: 200px;
    text-align: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    cursor: pointer;
    transition: transform 0.2s, box-shadow 0.2s;
}
.candidate-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}
.candidate-card img {
    width: 100%;
    height: 150px;
    object-fit: cover;
    border-radius: 8px;
    margin-bottom: 10px;
}
.modal {
    display: none;
    position: fixed;
    z-index: 999;
    padding-top: 100px;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0,0,0,0.6);
}
.modal-content {
    background: #fff;
    margin: auto;
    padding: 20px;
    border-radius: 12px;
    max-width: 500px;
    text-align: center;
    position: relative;
}
.modal-content img {
    max-width: 100%;
    border-radius: 8px;
    margin-bottom: 15px;
}
.close {
    position: absolute;
    top: 10px;
    right: 15px;
    color: #aaa;
    font-size: 24px;
    font-weight: bold;
    cursor: pointer;
}
.close:hover {
    color: #000;
}
    .navbar {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background-color: #2c3e50;
        color: white;
        display: flex;
        justify-content: space-between;
        padding: 5px 10px;
        align-items: center;
        z-index: 1000;
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }
    .navbar .logo {
        font-size: 20px;
        font-weight: bold;
    }
    .navbar .nav-links a {
        color: white;
        margin-left: 15px;
        text-decoration: none;
    }
    .navbar .nav-links a:hover {
        text-decoration: underline;
    }
    @media (max-width: 500px) {
        .container {
            margin: 20px;
            padding: 20px;
        }
    }
</style>
</head>
<body>
       <nav class="navbar">
        <div class="logo">OVS</div>
        <div class="nav-links">
             <a href='voter.php'" style="border-radius: 10px; padding: 8px 16px; background-color: white; color: black; border: none; cursor: pointer;">
  Home
</a>
        </div>
    </nav>
<div class="container">
    <h2>View Candidates</h2>

    <form method="POST">
        <select name="position" onchange="this.form.submit()">
            <option value="">-- Select Position --</option>
            <?php foreach ($positions as $pos): ?>
                <option value="<?= htmlspecialchars($pos) ?>" <?= ($pos === $selected_position) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($pos) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </form>

    <?php if ($selected_position && $candidates): ?>
        <div class="candidates">
            <?php foreach ($candidates as $cand): ?>
                <div class="candidate-card" onclick="openModal('<?= htmlspecialchars($cand['name']) ?>',
                 '<?= htmlspecialchars($cand['position']) ?>',
                  '<?= htmlspecialchars($cand['photo']) ?>', 
                  '<?= htmlspecialchars($cand['regno']) ?>')">
                    <?php if ($cand['photo'] && file_exists($cand['photo'])): ?>
                        <img src="<?= htmlspecialchars($cand['photo']) ?>" alt="<?= htmlspecialchars($cand['name']) ?>">
                    <?php else: ?>
                        <img src="../uploads/default.png" alt="No photo">
                    <?php endif; ?>
                    <strong><?= htmlspecialchars($cand['name']) ?></strong>
                    <div><?= htmlspecialchars($cand['position']) ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php elseif ($selected_position): ?>
        <p style="text-align:center;">No candidates found for this position.</p>
    <?php endif; ?>
</div>

<!-- Modal -->
<div id="candidateModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <h3 id="modalName"></h3>
        <p id="modalPosition"></p>
        <img id="modalPhoto" src="" alt="">
        <p id="modalRegNo"></p>
    </div>
</div>

<script>
function openModal(name, position, photo, regno) {
    document.getElementById('modalName').innerText = name;
    document.getElementById('modalPosition').innerText = "Position: " + position;
    document.getElementById('modalPhoto').src = photo ? photo : '../uploads/default.png';
    document.getElementById('modalRegNo').innerText = "Reg. Number: " + regno;
    document.getElementById('candidateModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('candidateModal').style.display = 'none';
}

// Close modal on click outside content
window.onclick = function(event) {
    if (event.target == document.getElementById('candidateModal')) {
        closeModal();
    }
}
</script>
</body>
</html>
