<?php
session_start();
include_once __DIR__ . '/../admin/database.php';

$message = '';
$positions = [];
$selected_position = $_POST['position'] ?? '';

// ✅ Check results release status
$settings = $conn->query("SELECT results_released FROM settings WHERE id = 1 LIMIT 1");
$settings_row = $settings ? $settings->fetch_assoc() : null;
$results_released = $settings_row['results_released'] ?? 0;

if ($results_released != 1) {
    $message = "⏳ Results are not yet ready. Please check back later.";
}

// Fetch all distinct positions
$result = $conn->query("SELECT DISTINCT position FROM candidates");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $positions[] = $row['position'];
    }
}

$results = [];
if ($selected_position && $results_released == 1) {
    // Fetch candidates and their vote counts for selected position
    $stmt = $conn->prepare("
        SELECT c.id, c.name, c.photo, COUNT(v.id) AS votes
        FROM candidates c
        LEFT JOIN votes v ON c.id = v.candidate_id
        WHERE c.position = ?
        GROUP BY c.id, c.name, c.photo
        ORDER BY votes DESC, c.name ASC
    ");
    $stmt->bind_param("s", $selected_position);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $results[] = $row;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>View Voting Results</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: #f4f4f4;
        margin: 100px;
    }
    form {
        background: white;
        padding: 20px 30px;
        max-width: 600px;
        border-radius: 10px;
        box-shadow: 0 0 15px rgba(0,0,0,0.1);
        margin-left: 240px;
        margin-bottom: 40px;
    }
    label, select, button {
        display: block;
        margin-bottom: 15px;
        font-size: 1rem;
    }
    select, button {
        padding: 10px;
        border-radius: 6px;
        border: 1px solid #ccc;
        width: 100%;
    }
    button {
         background-color: #2c3e50;
        color: white;
        border: none;
        cursor: pointer;
    }
    button:hover {
        background: #0056b3;
    }
    .results-table {
        max-width: 600px;
        margin-left: 240px;
        border-collapse: collapse;
        width: 100%;
        background: white;
        border-radius: 10px;
        box-shadow: 0 0 15px rgba(0,0,0,0.1);
        overflow: hidden;
    }
    .results-table th, .results-table td {
        padding: 12px 15px;
        border-bottom: 1px solid #ddd;
        text-align: left;
    }
    .results-table th {
        background-color: #2c3e50;
        color: white;
    }
    .results-table tr:last-child td {
        border-bottom: none;
    }
    .candidate-photo {
        width: 50px;
        height: 50px;
        object-fit: cover;
        border-radius: 6px;
    }
    .message {
        text-align:center;
        margin-bottom: 20px;
        padding: 15px;
        border-radius: 6px;
        background: #f8d7da;
        color: #721c24;
    }
    .navbar {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background-color: #2c3e50;
        color: white;
        display: flex;
        justify-content: space-between;
        padding: 5px 10px;
        align-items: center;
        z-index: 1000;
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }
    .navbar .logo {
        font-size: 20px;
        font-weight: bold;
    }
    .navbar .nav-links button {
        border-radius: 10px;
        padding: 8px 16px;
        background-color: white;
        color: black;
        border: none;
        cursor: pointer;
    }
    .navbar .nav-links button:hover {
        background-color: #ddd;
    }
    @media (max-width: 500px) {
        form, .results-table {
            margin-left: 20px;
            margin-right: 20px;
        }
    }
</style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">OVS</div>
        <div class="nav-links">
            <button onclick="window.location.href='voter.php'">Home</button>
        </div>
    </nav>

<h2 style="text-align:center;">View Voting Results</h2>

<?php if ($message): ?>
    <div class="message"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<form method="POST" action="">
    <label for="position">Select Position:</label>
    <select name="position" id="position" onchange="this.form.submit()">
        <option value="">-- Choose Position --</option>
        <?php foreach ($positions as $pos): ?>
            <option value="<?= htmlspecialchars($pos) ?>" <?= ($pos === $selected_position) ? 'selected' : '' ?>>
                <?= htmlspecialchars($pos) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <noscript><button type="submit">View Results</button></noscript>
</form>

<?php if ($results_released == 1 && $selected_position): ?>
    <?php if ($results): ?>
        <table class="results-table" aria-label="Voting results for <?= htmlspecialchars($selected_position) ?>">
            <thead>
                <tr>
                    <th>Candidate</th>
                    <th>Photo</th>
                    <th>Votes</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $row): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td>
                            <?php if ($row['photo'] && file_exists($row['photo'])): ?>
                                <img src="<?= htmlspecialchars($row['photo']) ?>" alt="<?= htmlspecialchars($row['name']) ?>" class="candidate-photo" />
                            <?php else: ?>
                                <span style="color:#999;">No photo</span>
                            <?php endif; ?>
                        </td>
                        <td><?= (int)$row['votes'] ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="margin-left:240px;">No candidates or votes found for this position.</p>
    <?php endif; ?>
<?php endif; ?>

</body>
</html>
