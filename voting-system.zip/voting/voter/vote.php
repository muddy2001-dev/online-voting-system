<?php
include_once __DIR__ . '/../admin/database.php';

$message = '';
$positions = [];
$candidates = [];
$selected_position = $_POST['position'] ?? '';
$vote_candidate_id = $_POST['candidate_id'] ?? null;

// ✅ Check voting status
$settings = $conn->query("SELECT voting_status FROM settings WHERE id = 1 LIMIT 1");
$settings_row = $settings ? $settings->fetch_assoc() : null;
$voting_status = $settings_row['voting_status'] ?? 0;

if ($voting_status != 1) {
    $message = "⏳ Voting is not yet open. Please wait for the admin to start the election.";
} else {

    // Get user IP (simplified)
    function getUserIP() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        }
        return $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
    }

    $user_ip = getUserIP();

    // Fetch all distinct positions
    $result = $conn->query("SELECT DISTINCT position FROM candidates");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $positions[] = $row['position'];
        }
    }

    // Handle vote submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['vote'])) {
        if (!$selected_position) {
            $message = "⚠️ Please select a position.";
        } elseif (!$vote_candidate_id) {
            $message = "⚠️ Please select a candidate to vote for.";
        } else {
            // Check if user/IP already voted for this position
            $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM votes WHERE position = ? AND voter_ip = ?");
            $stmt->bind_param("ss", $selected_position, $user_ip);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $stmt->close();

            if ($row['count'] > 0) {
                $message = "⚠️ You have already voted for the position: " . htmlspecialchars($selected_position);
            } else {
                // Insert vote
                $stmt = $conn->prepare("INSERT INTO votes (candidate_id, position, voter_ip) VALUES (?, ?, ?)");
                $stmt->bind_param("iss", $vote_candidate_id, $selected_position, $user_ip);
                if ($stmt->execute()) {
                    $message = "✅ Your vote for candidate ID $vote_candidate_id for position " . htmlspecialchars($selected_position) . " has been recorded.";
                } else {
                    $message = "❌ Failed to record your vote: " . $stmt->error;
                }
                $stmt->close();
            }
        }
    }

    // If a position is selected, fetch candidates for that position
    if ($selected_position) {
        $stmt = $conn->prepare("SELECT * FROM candidates WHERE position = ?");
        $stmt->bind_param("s", $selected_position);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $candidates[] = $row;
        }
        $stmt->close();
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Vote for Candidate</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: #f4f4f4;
        margin: 100px;
    }
    form {
        background: white;
        padding: 20px 30px;
        max-width: 600px;
        border-radius: 10px;
        box-shadow: 0 0 15px rgba(0,0,0,0.1);
        margin-left:240px;
    }
    label, select, button {
        display: block;
        margin-bottom: 15px;
        font-size: 1rem;
    }
    select, button {
        padding: 10px;
        border-radius: 6px;
        border: 1px solid #ccc;
        width: 100%;
    }
    button {
        background: #007bff;
        color: white;
        border: none;
        cursor: pointer;
    }
    button:hover {
        background: #0056b3;
    }
    .candidates {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        margin-bottom: 20px;
    }
    .candidate {
        border: 1px solid #ccc;
        border-radius: 10px;
        background: white;
        padding: 10px;
        width: 180px;
        text-align: center;
    }
    .candidate img {
        max-width: 100%;
        max-height: 150px;
        border-radius: 6px;
    }
    .message {
        margin-bottom: 20px;
        padding: 15px;
        border-radius: 6px;
        text-align:center;
    }
    .success {
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }
    .error {
        background: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
    .navbar {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background-color: #2c3e50;
        color: white;
        display: flex;
        justify-content: space-between;
        padding: 5px 10px;
        align-items: center;
        z-index: 1000;
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }
    .navbar .logo {
        font-size: 20px;
        font-weight: bold;
    }
    .navbar .nav-links a {
        color: white;
        margin-left: 15px;
        text-decoration: none;
    }
    .navbar .nav-links a:hover {
        text-decoration: underline;
    }
    @media (max-width: 500px) {
        .container {
            margin: 20px;
            padding: 20px;
        }
    }
</style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">OVS</div>
        <div class="nav-links">
             <a href='voter.php'" style="border-radius: 10px; padding: 8px 16px; background-color: white; color: black; border: none; cursor: pointer;">
  Home
</a>
        </div>
    </nav>
<h2 style="text-align:center;">Vote for Your Candidate</h2>

<?php if ($message): ?>
    <div class="message <?= strpos($message, '✅') === 0 ? 'success' : 'error' ?>">
        <?= htmlspecialchars($message) ?>
    </div>
<?php endif; ?>

<form method="POST" action="">
    <label for="position">Select Position:</label>
    <select name="position" id="position" onchange="this.form.submit()">
        <option value="">-- Choose Position --</option>
        <?php foreach ($positions as $pos): ?>
            <option value="<?= htmlspecialchars($pos) ?>" <?= ($pos === $selected_position) ? 'selected' : '' ?>>
                <?= htmlspecialchars($pos) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <noscript><button type="submit" name="load_candidates">Load Candidates</button></noscript>

    <?php if ($selected_position): ?>
        <div class="candidates">
            <?php if ($candidates): ?>
                <?php foreach ($candidates as $cand): ?>
                    <label class="candidate">
                        <input type="radio" name="candidate_id" value="<?= $cand['id'] ?>" required>
                        <div><strong><?= htmlspecialchars($cand['name']) ?></strong></div>
                        <div><em><?= htmlspecialchars($cand['position']) ?></em></div>
                        <?php if ($cand['photo'] && file_exists($cand['photo'])): ?>
                            <img src="<?= htmlspecialchars($cand['photo']) ?>" alt="<?= htmlspecialchars($cand['name']) ?>">
                        <?php else: ?>
                            <div style="font-size: 0.9em; color: #999;">No photo</div>
                        <?php endif; ?>
                    </label>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No candidates found for this position.</p>
            <?php endif; ?>
        </div>

        <button type="submit" name="vote">Vote</button>
    <?php endif; ?>
</form>

</body>
</html>
