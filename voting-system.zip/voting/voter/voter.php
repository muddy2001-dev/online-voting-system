<?php

session_name("voter_session");
session_start();

if (!isset($_SESSION['voter_id'])) {
    // Not logged in, redirect to login page or show error
    header("Location: voter-login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ajax Sidebar Layout</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
  

<div class="header">
    <?php include_once 'header2.php'; ?>
  </div>

    <!-- Content -->
    <div class="content" id="mainContent">
     <h3>Welcome to Your Dashboard</h3>

    <div class="dashboard-cards">
       
            <a href="vote.php" class="card-link">
               <div class="card">
                <div class="card-logo">📝</div>
                <strong>Voting for Candidate</strong>
            </div>
             </a>

    <a href="voter_detail.php" class="card-link">
               <div class="card">
                <div class="card-logo">📝</div>
                <strong>Voter Details</strong>
            </div>
             </a>

               <a href="view_candidates.php" class="card-link">
               <div class="card">
                <div class="card-logo">📝</div>
                <strong>Candidate Details</strong>
            </div>
             </a>
            <a href="event.php" class="card-link">
               <div class="card">
                <div class="card-logo">🗓️</div>
                <strong>Upcoming events</strong>
            </div>
             </a>
              <a href="voting_result.php" class="card-link">
               <div class="card">
                <div class="card-logo">🗓️</div>
                <strong>Voting Results</strong>
            </div>
             </a>

       
        </a>
    </div>
  </div>
<script src="ajax/assets/ajax-forms.js"></script>


</body>
</html>
