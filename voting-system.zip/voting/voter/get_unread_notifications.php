<?php
session_name("voter_session");
session_start();
 include_once __DIR__ . '/../database.php';

$voterId = $_SESSION['voter_id'] ?? null;

if (!$voterId) {
    echo json_encode(["count" => 0]);
    exit;
}

$stmt = $conn->prepare("SELECT COUNT(*) as unread FROM notifications WHERE voter_id = ? AND is_read = 0");
$stmt->bind_param("i", $voterId);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

echo json_encode(["count" => $row['unread']]);
$stmt->close();
?>
