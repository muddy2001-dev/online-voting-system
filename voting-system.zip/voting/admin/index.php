<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ajax Sidebar Layout</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

  <!-- Header -->
  <div class="header">
    <?php include_once 'header.php'; ?>
  </div>

  <!-- Sidebar + Content Layout -->
  <div class="main-layout">
    <!-- Sidebar -->
    <div class="sidebar">
      <h2><i class="fas fa-bars"></i> Menu</h2>
      <ul>
        
        <!-- Student Classes Accordion -->
        <li class="accordion-item">
          <a href="#" onclick="toggleAccordion('accordionClasses')"><i class="fas fa-school"></i> Voters</a>
          <ul class="accordion-content" id="accordionClasses">
            <li><a href="#" onclick="loadPage('voter.php')">Add Voter</a></li>
            <li><a href="#" onclick="loadPage('manage_voter.php')">Manage Voters</a></li>

            
          </ul>
        </li>

        <!-- Subjects Accordion -->
        <li class="accordion-item">
          <a href="#" onclick="toggleAccordion('accordionSubjects')"><i class="fas fa-book"></i> Candidates</a>
          <ul class="accordion-content" id="accordionSubjects">
            <li><a href="#" onclick="loadPage('candidate.php')">Add Candidate</a></li>
            <li><a href="#" onclick="loadPage('manage_candidate.php')">Manage Candidates</a></li>
          </ul>
        </li>
           <!-- Results Accordion -->
        <li class="accordion-item">
          <a href="#" onclick="toggleAccordion('accordionResults')"><i class="fas fa-book"></i> Results</a>
          <ul class="accordion-content" id="accordionResults">
            <li><a href="#" onclick="loadPage('manage_voting.php')">Voting & Results</a></li>
            <li><a href="#" onclick="loadPage('delete_vote.php')">Manage Results</a></li>
          </ul>
        </li>
          <!-- Notices Accordion -->
        <li class="accordion-item">
          <a href="#" onclick="toggleAccordion('accordionNotices')"><i class="fas fa-book"></i> Notices</a>
          <ul class="accordion-content" id="accordionNotices">
            <li><a href="#" onclick="loadPage('faq.php')">Voters Notice</a></li>
            <li><a href="#" onclick="loadPage('manage_notice.php')">Manage Notices</a></li>
          </ul>
        </li>

        <!-- Direct Links -->
        <li><a href="#" onclick="loadPage('update.php')"><i class="fas fa-info-circle"></i> Settings</a></li>
         <li><a href="#" onclick="loadPage('index.php')"><i class="fas fa-info-circle"></i> Home</a></li>
      </ul>
    </div>

    <!-- Content -->
    <div class="content" id="mainContent">
    <h3> <marquee>Welcome To Online Voting System</marquee></h3>

    <div class="dashboard-cards">
     
             <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_voters.php')">
               <div class="card">
                <div class="card-logo">📝</div>
                <strong>Registered Voters</strong>
            </div>
             </a>
               <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_candidate.php')">
               <div class="card">
                <div class="card-logo">🗓️</div>
                <strong>Registered Candidates</strong>
            </div>
             </a>

           <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_result.php')">
               <div class="card">
                <div class="card-logo">🗓️</div>
                <strong>Voting Results</strong>
            </div>
             </a>

        
          <a href="javascript:void(0);" class="card-link" onclick="loadPage('report_summary_votes.php')">
            <div class="card">
                <div class="card-logo">💳</div>
                <strong> Reports</strong>
            </div>
        </a>

     
    </div>
  </div>

<script>
// Load any page via AJAX
function loadPage(page) {
  fetch("../ajax/" + page)
    .then(res => res.text())
    .then(html => {
      const mainContent = document.getElementById("mainContent");
      mainContent.innerHTML = html;

// --- delete_vote.php ---
if (page === 'delete_vote.php') {
    const form = document.getElementById('deleteVoteForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault(); // prevent full reload

            const formData = new FormData(form);
            // manually add the 'delete' field so PHP can detect it
            formData.append('delete', 1);

            fetch('../ajax/delete_vote.php', {
                method: 'POST',
                body: formData,
                headers: { 'X-Requested-With': 'XMLHttpRequest' } // mark as AJAX
            })
            .then(res => res.json())
            .then(data => {
                let msgDiv = document.querySelector('.message');
                if (!msgDiv) {
                    msgDiv = document.createElement('div');
                    form.insertAdjacentElement('afterend', msgDiv);
                }

                msgDiv.className = 'message';
                msgDiv.style.marginTop = '20px';
                msgDiv.style.padding = '15px';
                msgDiv.style.borderRadius = '6px';
                msgDiv.style.textAlign = 'center';

                if (data.success) {
                    msgDiv.style.background = '#d4edda';
                    msgDiv.style.color = '#155724';
                    msgDiv.style.border = '1px solid #c3e6cb';
                } else {
                    msgDiv.style.background = '#f8d7da';
                    msgDiv.style.color = '#721c24';
                    msgDiv.style.border = '1px solid #f5c6cb';
                }

                msgDiv.innerHTML = data.message;
            })
            .catch(err => alert("Failed to delete votes: " + err));
        });
    }
}

function attachVoteSummaryFilter() {
  const filterForm = document.querySelector('#voteFilterForm');
  if (filterForm) {
    filterForm.addEventListener('submit', function(e) {
      e.preventDefault();

      const positionVal = this.querySelector('#position').value.trim();

      if (!positionVal) {
        const mainContent = document.getElementById('mainContent');
        mainContent.innerHTML = `<p style="color: red; font-weight: bold;">Please select a position to generate report.</p>`;
        return;
      }

      const params = new URLSearchParams({ position: positionVal });

      fetch('ajax/report_summary_votes.php?' + params.toString())
        .then(res => res.text())
        .then(html => {
          const mainContent = document.getElementById('mainContent');
          mainContent.innerHTML = html;
          attachVoteSummaryFilter(); // reattach handler
        })
        .catch(() => alert('Failed to load voting summary report'));
    }, { once: true });
  }
}

if (page === 'report_summary_votes.php') {
  attachVoteSummaryFilter();
}


      // --- view_result.php ---
      if (page === 'view_result.php') {
        const form = document.querySelector('form');
        if (form) {
          form.addEventListener('change', function (e) {
            if (e.target.name === 'position') {
              const formData = new FormData(form);
              fetch('../ajax/view_result.php', {
                method: 'POST',
                body: formData
              })
              .then(res => res.text())
              .then(html => {
                // Replace only the results table/message
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');

                // Replace message div
                const messageDiv = doc.querySelector('.message');
                const oldMessageDiv = document.querySelector('.message');
                if (oldMessageDiv) oldMessageDiv.innerHTML = messageDiv ? messageDiv.innerHTML : '';

                // Replace results table
                const newTable = doc.querySelector('.results-table');
                const oldTable = document.querySelector('.results-table');
                if (oldTable) {
                  if (newTable) oldTable.replaceWith(newTable);
                  else oldTable.remove();
                } else if (newTable) {
                  // append new table if none existed before
                  form.insertAdjacentElement('afterend', newTable);
                }
              })
              .catch(() => alert('Failed to load results'));
            }
          });
        }
      }


     // --- manage_voting.php ---
if (page === 'manage_voting.php') {
  const form = document.getElementById('votingSettingsForm');
  if (form) {
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      const formData = new FormData(form);

      fetch('../ajax/save_voting_settings.php', {
        method: 'POST',
        body: formData
      })
        .then(res => res.json())
        .then(data => {
          const msg = document.getElementById('votingMessage');
          if (data.success) {
            msg.innerHTML = `<span style="color:green;">${data.success}</span>`;
          } else if (data.error) {
            msg.innerHTML = `<span style="color:red;">${data.error}</span>`;
          }
        })
        .catch(() => alert("Error saving settings"));
    });
  }
}


      // --- update.php ---
      if (page.startsWith('update.php')) {
        const form = document.getElementById('updateForm');
        if (form) {
          form.addEventListener('submit', function (e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('../ajax/update.php', {
              method: 'POST',
              body: formData
            })
              .then(res => res.json())
              .then(data => {
                const messageDiv = document.querySelector('.message');
                if (data.success) {
                  messageDiv.innerHTML = `<strong style="color:green;">${data.success}</strong>`;
                } else if (data.error) {
                  messageDiv.innerHTML = `<strong style="color:red;">${data.error}</strong>`;
                }
              })
              .catch(() => alert('Failed to update details'));
          });
        }

        // Ensure links work
        document.querySelectorAll('.settings-options a').forEach(link => {
          link.addEventListener('click', function (e) {
            e.preventDefault();
            const href = this.getAttribute('href');
            if (href.endsWith('.php')) {
              loadPage(href);
            }
          });
        });
      }

      // --- candidate.php ---
      if (page === 'candidate.php') {
        const form = document.getElementById('faqForm');
        if (form) {
          form.addEventListener('submit', function (e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('../ajax/candidate.php', {
              method: 'POST',
              body: formData
            })
              .then(res => res.json())
              .then(data => {
                const responseDiv = document.getElementById('responseMessage');
                if (data.success) {
                  responseDiv.innerHTML = `<div class="msg">${data.success}</div>`;
                  form.reset();
                } else if (data.error) {
                  responseDiv.innerHTML = `<div class="err">${data.error}</div>`;
                }
              })
              .catch(() => alert('Failed to submit form'));
          });
        }
      }

      // --- voter.php ---
      if (page === 'voter.php') {
        const form = document.getElementById('faqForm');
        if (form) {
          form.addEventListener('submit', function (e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('../ajax/voter.php', {
              method: 'POST',
              body: formData
            })
              .then(res => res.json())
              .then(data => {
                const responseDiv = document.getElementById('responseMessage');
                if (data.success) {
                  responseDiv.innerHTML = `<div class="msg">${data.success}</div>`;
                  form.reset();
                } else if (data.error) {
                  responseDiv.innerHTML = `<div class="err">${data.error}</div>`;
                }
              })
              .catch(() => alert('Failed to submit form'));
          });
        }
      }

      // --- change_password.php ---
      if (page === 'change_password.php') {
        const form = document.getElementById('changePasswordForm');
        const newFields = document.getElementById('newPasswordFields');

        if (form) {
          form.addEventListener('submit', function (e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('../ajax/change_password.php', {
              method: 'POST',
              body: formData
            })
              .then(res => res.json())
              .then(data => {
                const responseDiv = document.getElementById('responseMessage');
                if (data.show_new) {
                  newFields.style.display = 'block';
                  responseDiv.innerHTML = '';
                  form.querySelector('input[type=submit]').value = 'Update Password';
                } else if (data.success) {
                  responseDiv.innerHTML = `<div style="color:green;">${data.success}</div>`;
                  form.reset();
                  newFields.style.display = 'none';
                  form.querySelector('input[type=submit]').value = 'Verify Current Password';
                } else if (data.error) {
                  responseDiv.innerHTML = `<div style="color:red;">${data.error}</div>`;
                }
              })
              .catch(() => alert('Failed to submit form'));
          });
        }
      }

      // --- faq.php ---
      if (page === 'faq.php') {
        const form = document.getElementById('faqForm');
        if (form) {
          form.addEventListener('submit', function (e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('../ajax/faq.php', {
              method: 'POST',
              body: formData
            })
              .then(res => res.json())
              .then(data => {
                const responseDiv = document.getElementById('responseMessage');
                if (data.success) {
                  responseDiv.innerHTML = `<div class="msg">${data.success}</div>`;
                  form.reset();
                } else if (data.error) {
                  responseDiv.innerHTML = `<div class="err">${data.error}</div>`;
                }
              })
              .catch(() => alert('Failed to submit form'));
          });
        }
      }

      // --- edit_notice.php ---
      if (page.startsWith('edit_notice.php')) {
        const form = document.getElementById('editNoticeForm');
        if (form) {
          form.addEventListener('submit', function (e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('../ajax/update_notice.php', {
              method: 'POST',
              body: formData
            })
              .then(res => res.json())
              .then(data => {
                const msg = document.getElementById('editResponse');
                if (data.success) {
                  msg.innerHTML = `<span style='color:green;'>${data.success}</span>`;
                  setTimeout(() => loadPage('manage_notice.php'), 800);
                } else if (data.error) {
                  msg.innerHTML = `<span style='color:red;'>${data.error}</span>`;
                }
              })
              .catch(() => alert('Error updating notice'));
          });
        }
      }

      if (page === 'manage_notice.php') {
        document.querySelectorAll('.delete-btn').forEach(btn => {
          btn.addEventListener('click', function () {
            if (confirm('Are you sure you want to delete this notice?')) {
              const id = this.getAttribute('data-id');
              fetch(`../ajax/delete_notice.php?id=${id}`)
                .then(res => res.json())
                .then(data => {
                  if (data.success) {
                    loadPage('manage_notice.php');
                  } else {
                    alert(data.error || 'Failed to delete notice');
                  }
                });
            }
          });
        });

        document.querySelectorAll('.edit-btn').forEach(btn => {
          btn.addEventListener('click', function () {
            const id = this.getAttribute('data-id');
            loadPage(`edit_notice.php?id=${id}`);
          });
        });
      }

      // --- edit_voter.php ---
      if (page.startsWith('edit_voter.php')) {
        const form = document.getElementById('editVoterForm');
        if (form) {
          form.addEventListener('submit', function (e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('../ajax/update_voter.php', {
              method: 'POST',
              body: formData
            })
              .then(res => res.json())
              .then(data => {
                const msg = document.getElementById('editResponse');
                if (data.success) {
                  msg.innerHTML = `<span style='color:green;'>${data.success}</span>`;
                  setTimeout(() => loadPage('manage_voter.php'), 800);
                } else if (data.error) {
                  msg.innerHTML = `<span style='color:red;'>${data.error}</span>`;
                }
              })
              .catch(() => alert('Error updating voter'));
          });
        }
      }

      if (page === 'manage_voter.php') {
        document.querySelectorAll('.delete-btn').forEach(btn => {
          btn.addEventListener('click', function () {
            if (confirm('Are you sure you want to delete this voter?')) {
              const id = this.getAttribute('data-id');
              fetch(`../ajax/delete_voter.php?id=${id}`)
                .then(res => res.json())
                .then(data => {
                  if (data.success) {
                    loadPage('manage_voter.php');
                  } else {
                    alert(data.error || 'Failed to delete voter');
                  }
                });
            }
          });
        });

        document.querySelectorAll('.edit-btn').forEach(btn => {
          btn.addEventListener('click', function () {
            const id = this.getAttribute('data-id');
            loadPage(`edit_voter.php?id=${id}`);
          });
        });
      }

      // --- edit_candidate.php ---
      if (page.startsWith('edit_candidate.php')) {
        const form = document.getElementById('editCandidateForm');
        if (form) {
          form.addEventListener('submit', function (e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('../ajax/update_candidate.php', {
              method: 'POST',
              body: formData
            })
              .then(res => res.json())
              .then(data => {
                const msg = document.getElementById('editResponse');
                if (data.success) {
                  msg.innerHTML = `<span style='color:green;'>${data.success}</span>`;
                  setTimeout(() => loadPage('manage_candidate.php'), 800);
                } else if (data.error) {
                  msg.innerHTML = `<span style='color:red;'>${data.error}</span>`;
                }
              })
              .catch(() => alert('Error updating candidate'));
          });
        }
      }

      if (page === 'manage_candidate.php') {
        document.querySelectorAll('.delete-btn').forEach(btn => {
          btn.addEventListener('click', function () {
            if (confirm('Are you sure you want to delete this candidate?')) {
              const id = this.getAttribute('data-id');
              fetch(`../ajax/delete_candidate.php?id=${id}`)
                .then(res => res.json())
                .then(data => {
                  if (data.success) {
                    loadPage('manage_candidate.php');
                  } else {
                    alert(data.error || 'Failed to delete candidate');
                  }
                });
            }
          });
        });

        document.querySelectorAll('.edit-btn').forEach(btn => {
          btn.addEventListener('click', function () {
            const id = this.getAttribute('data-id');
            loadPage(`edit_candidate.php?id=${id}`);
          });
        });
      }
    })
    .catch(() => {
      document.getElementById("mainContent").innerHTML = "<p>Error loading page.</p>";
    });
}

// Toggle accordion
function toggleAccordion(id) {
  const accordions = document.querySelectorAll(".accordion-content");
  accordions.forEach(acc => {
    if (acc.id !== id) acc.style.display = "none";
  });
  const content = document.getElementById(id);
  if (content) content.style.display = (content.style.display === "block") ? "none" : "block";
}

// Logout confirmation
function confirmLogout() {
  if (confirm("Are you sure you want to logout?")) {
    window.location.href = "logout.php";
  }
}
</script>


</body>
</html>
