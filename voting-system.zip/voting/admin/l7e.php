<?php

session_name("admin_session");
session_start();
if (!isset($_SESSION['admin_id'])) {
    // Not logged in, redirect to login page or show error
    header("Location: login.php");
    exit();
}
include 'database.php';

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    $email = trim($_POST['email']);

    // Generate random OTP
    function generateRandomOTP()
    {
        $length = 6;
        $characters = '0123456789';
        $otp = '';
        for ($i = 0; $i < $length; $i++) {
            $otp .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $otp;
    }
    $hiddenOTP = generateRandomOTP();

    // Check if email exists
    $stmt = $conn->prepare("SELECT id FROM admin WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 1) {
        $_SESSION['email'] = $email;

        $updateSql = "UPDATE admin SET otp=?, otp_generated_time=NOW() WHERE email=?";
        $upd = $conn->prepare($updateSql);
        $upd->bind_param("ss", $hiddenOTP, $email);

        if ($upd->execute()) {
            header("Location: l12e.php?email=" . urlencode($email));
            exit();
        } else {
            $error = "ERROR: Could not update OTP.";
        }
    } else {
        $error = "Email not found in the database.";
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f2f5f7;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color:#2c3e50;
            color: white;
            display: flex;
            justify-content: space-between;
            padding: 5px 10px;
            align-items: center;
        }
        .navbar .nav-links button {
            background: #3498db;
            border: none;
            padding: 5px 10px;
            color: #fff;
            cursor: pointer;
        }
        .container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        h3 {
            text-align: center;
            color: #333;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }
        input[type="email"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #2c3e50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .error {
            color: red;
            font-size: 14px;
            margin-top: -10px;
            margin-bottom: 15px;
            text-align: center;
        }
    </style>
</head>
<body>
<nav class="navbar">
  <div class="logo">SRMS</div>
  <div class="nav-links">
    <button onclick="window.history.back()">Back</button>
  </div>
</nav>
<div class="container">
    <h3>Enter your Email</h3>
    <form method="post" action="">
        <label for="email">Email:</label>
        <input type="email" name="email" value="<?= isset($email) ? htmlspecialchars($email) : '' ?>" required><br>
        <?php if (!empty($error)): ?>
            <p class="error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
        <input type="submit" value="Send">
    </form>
</div>
</body>
</html>
