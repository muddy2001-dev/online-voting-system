<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Us </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }
          .navbar {
            background-color:#2c3e50;
            color: white;
            display: flex;
            justify-content: space-between;
            padding: 8px 15px;
            align-items: center;
        }
    

        .container {
            max-width: 500px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
           input[type="submit"] {
            background-color: #2c3e50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
         
        }

        h2 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: 500;
        }
 input[type="number"],
        input[type="text"],
        input[type="email"],
        textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            margin-top: 5px;
            border: 1px solid #ccc;
            background-color: #fff;
        }

        textarea {
            resize: vertical;
        }

       

        button:hover {
            background-color: #0056b3;
        }

        .success-message, .error-message {
            margin: 20px auto;
            max-width: 500px;
            padding: 15px;
            border-radius: 5px;
            font-size: 15px;
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
        }

        .error-message {
            background-color: #f8d7da;
            color: #721c24;
        }

        .success-message a {
            display: inline-block;
            margin-top: 10px;
            color: #007bff;
            text-decoration: none;
        }

        .success-message a:hover {
            text-decoration: underline;
        }

        @media (max-width: 500px) {
            .container {
                margin: 20px;
                padding: 20px;
            }
        }
                        /* Dark mode styling */
.p{
            text-align:right;
        }


    </style>
    
</head>
<body>
    

  <nav class="navbar">
        <div class="logo">SRMS</div>
         <button class="p" onclick="window.history.back()">Back
</button>
    </nav>

    <?php if (isset($_GET['success'])): ?>
        <div class="success-message">
            Your message has been sent successfully.<br>
            <a href="index.php">Return to Homepage</a>
        </div>
    <?php elseif (isset($_GET['error'])): ?>
        <div class="error-message">
            <?php
            switch ($_GET['error']) {
                case 'invalid_email':
                    echo "Please provide a valid email address.";
                    break;
                case 'database_error':
                    echo "There was a problem saving your message. Please try again.";
                    break;
                case 'mail_failed':
                    echo "Message could not be sent. Please try again later.";
                    break;
                default:
                    echo "An error occurred. Please try again.";
            }
            ?>
        </div>
    <?php endif; ?>

    <div class="container">
        <form action="send_message.php" method="POST">
            <h3 style="text-align:center";>Contact Us</h3>
            <label for="name">Your Full Name</label>
            <input type="text" id="name" name="name" placeholder="(e.g Ali Rashid Juma)" required>

            <label for="email">Your Email</label>
            <input type="email" id="email" name="email" placeholder="(e.g support@gmail.com)" required>

            <label for="phone">Phone Number</label>
            <input type="number" id="phone" name="phone" placeholder="(e.g 0777XXXXXX)" required>

            <label for="message">Message</label>
            <textarea id="message" name="message" rows="4" required></textarea>

           
            <input type="submit" value="Send Message">
        </form>
    </div>
  
</body>
</html>
