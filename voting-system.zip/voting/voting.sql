-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2025 at 02:36 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `voting`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `otp` varchar(255) NOT NULL,
  `otp_generated_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `phone`, `password`, `otp`, `otp_generated_time`, `is_read`, `created_at`) VALUES
(1, 'Admin Admin', 'admin@example.com', '0772516273', '$2y$10$gaMF79gnaFhPrg2H4egAsORVQ5uLPQ9yf20tvTj52PHUEBfCcIgBK', '', '2025-09-17 12:35:19', 0, '2025-09-04 11:52:19');

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `position` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `regno` varchar(50) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `dob` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`id`, `name`, `position`, `photo`, `regno`, `phone`, `gender`, `dob`, `created_at`) VALUES
(2, 'asma said Khalfan', 'President', '../uploads/1757083770_cruise-ship-48fv0tg5inbcobk9.jpg', 'WSS-2025-36437', 772345367, 'Male', '2025-09-05', '2025-09-07 21:00:00'),
(3, 'Rashid Salim', 'Vice president', '../uploads/1757147534_baby-animals-wmsvikfmzvhh3aot.jpg', 'WSS-2025-95432', 773245167, 'Male', '2025-09-11', '2025-09-06 08:32:14'),
(4, 'Salma Salim Said', 'President', '../uploads/1757147584_5bd32a27cd984-wallpaper-preview.jpg', 'WSS-2025-34281', 774235627, 'Female', '2025-09-18', '2025-09-16 21:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(11) NOT NULL,
  `tittle` text NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `tittle`, `message`, `created_at`) VALUES
(2, 'TAAARIFA YA UCHAGUZI', 'Siku ya Ijumaa ya tarehe 2 january mwaka 2025 utafanyika uchaguzi wa shule', '2025-01-01 21:00:00'),
(3, 'Uchaguzi wa ndani', 'siku ya jumatano.....', '2025-09-12 12:48:11');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `voter_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `message`, `is_read`, `created_at`, `voter_id`) VALUES
(1, '📢 New Notice posted: t', 0, '2025-09-04 13:16:24', 1),
(2, '📢 New Notice posted: t', 0, '2025-09-04 13:16:24', 2),
(3, '📢 New Notice posted: Uchaguzi wa ndani', 0, '2025-09-12 12:48:11', 1),
(4, '📢 New Notice posted: Uchaguzi wa ndani', 1, '2025-09-12 12:48:11', 3),
(5, '📢 New Notice posted: gg', 0, '2025-09-12 12:50:42', 1),
(6, '📢 New Notice posted: gg', 1, '2025-09-12 12:50:42', 3),
(7, '📢 New Notice posted: gg', 0, '2025-09-12 12:51:00', 1),
(8, '📢 New Notice posted: gg', 1, '2025-09-12 12:51:00', 3),
(9, '📢 New Notice posted: gg', 0, '2025-09-12 12:55:21', 1),
(10, '📢 New Notice posted: gg', 1, '2025-09-12 12:55:21', 3),
(11, '📢 New Notice posted: fvd', 0, '2025-09-12 13:31:14', 1),
(12, '📢 New Notice posted: fvd', 1, '2025-09-12 13:31:14', 3),
(13, '📢 New Notice posted: dd', 0, '2025-09-12 13:37:28', 1),
(14, '📢 New Notice posted: dd', 1, '2025-09-12 13:37:28', 3),
(15, '📢 New Notice posted: uchaguzi', 0, '2025-09-17 11:44:27', 3),
(16, '📢 New Notice posted: uchaguzi', 1, '2025-09-17 11:44:27', 4);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `voting_status` tinyint(1) NOT NULL DEFAULT 0,
  `results_released` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `voting_status`, `results_released`) VALUES
(1, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `voters`
--

CREATE TABLE `voters` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `regno` varchar(50) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `dob` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `voters`
--

INSERT INTO `voters` (`id`, `name`, `regno`, `phone`, `gender`, `dob`, `created_at`) VALUES
(3, 'Abdalla Ali Hamad', 'WSS-2025-94607', 773452611, 'Male', '2025-09-25', '2025-09-15 21:00:00'),
(4, 'Salim Said Salim', 'WSS-2025-09289', 772134256, 'Male', '2025-09-17', '2025-09-17 11:42:12');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  `position` varchar(100) NOT NULL,
  `vote_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `voter_ip` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`id`, `candidate_id`, `position`, `vote_time`, `voter_ip`) VALUES
(4, 4, 'President', '2025-09-17 11:51:35', '::1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `candidates`
--
ALTER TABLE `candidates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voters`
--
ALTER TABLE `voters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_vote` (`position`,`voter_ip`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `candidates`
--
ALTER TABLE `candidates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `voters`
--
ALTER TABLE `voters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
