<?php
session_start();
include_once __DIR__ . '/../admin/database.php';

header('Content-Type: application/json');

// Get voting settings
$stmt = $conn->prepare("SELECT value FROM settings WHERE key_name = ?");
$keys = ['voting_status', 'results_released'];
$settings = [];

foreach ($keys as $key) {
    $stmt->bind_param('s', $key);
    $stmt->execute();
    $stmt->bind_result($val);
    if ($stmt->fetch()) {
        $settings[$key] = $val;
    }
    $stmt->free_result();
}
$stmt->close();

if (!isset($settings['results_released']) || $settings['results_released'] !== 'yes') {
    echo json_encode(['ready' => false, 'message' => 'Results are not yet ready. Please check back later.']);
    exit;
}

$position = $_GET['position'] ?? '';
if (!$position) {
    echo json_encode(['ready' => true, 'error' => 'No position selected']);
    exit;
}

// Fetch candidates and their vote counts for position
$stmt = $conn->prepare("
    SELECT c.id, c.name, c.photo, COUNT(v.id) AS votes
    FROM candidates c
    LEFT JOIN votes v ON c.id = v.candidate_id
    WHERE c.position = ?
    GROUP BY c.id, c.name, c.photo
    ORDER BY votes DESC, c.name ASC
");
$stmt->bind_param('s', $position);
$stmt->execute();
$result = $stmt->get_result();

$candidates = [];
while ($row = $result->fetch_assoc()) {
    $candidates[] = $row;
}
$stmt->close();

echo json_encode([
    'ready' => true,
    'position' => $position,
    'candidates' => $candidates,
]);
