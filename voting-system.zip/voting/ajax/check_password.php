<?php
include_once __DIR__ . '/../admin/database.php';

session_name("admin_session");
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'error' => 'not_logged_in']);
    exit;
}

$email = $_SESSION['admin_id'];
$password = $_POST['password'] ?? '';

if (!$password) {
    echo json_encode(['success' => false, 'error' => 'missing_password']);
    exit;
}

// Fetch hashed password from DB using email
$stmt = $conn->prepare("SELECT password FROM admin WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
    if (password_verify($password, $user['password'])) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'incorrect_password']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'user_not_found']);
}

$stmt->close();
$conn->close();
?>
