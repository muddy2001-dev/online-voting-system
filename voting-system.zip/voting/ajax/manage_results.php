<?php 
include_once '../database.php';

// Handle search query if provided
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$stmt_sql = "
    SELECT r.id as result_id, r.student_id, r.subject_id, r.marks, 
           rd.id as detail_id, rd.exam_type, rd.grade, rd.division, rd.points,
           s.subject, st.name, st.regno
    FROM results r
    INNER JOIN result_details rd ON r.id = rd.result_id
    INNER JOIN subjects s ON r.subject_id = s.id
    INNER JOIN students st ON r.student_id = st.id
    WHERE st.name LIKE ?
    ORDER BY st.name, rd.exam_type, s.subject
";

$stmt = $conn->prepare($stmt_sql);
$like = "%" . $search . "%";
$stmt->bind_param("s", $like);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Results</title>
    <style>
        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 20px;
        }
        .search-container {
            text-align: center;
            margin-bottom: 15px;
        }
        .search-container input {
            padding: 8px;
            width: 250px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .search-container button {
            padding: 8px 14px;
            border: none;
            border-radius: 5px;
            background-color: #2c3e50;
            color: #fff;
            cursor: pointer;
        }
        table {
            width: 100%;
            margin: 0 auto 30px auto;
            border-collapse: collapse;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
        }
        th {
            background-color: #2c3e50;
            color: #fff;
            text-transform: uppercase;
            font-size: 14px;
        }
        tr { background-color: #fff; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        tr:hover { background-color: #d6eaf8; }
        .action-btn {
            padding: 5px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
        .edit-btn { background-color: #2ecc71; color: white; margin-right: 5px; }
        .delete-btn { background-color: #e74c3c; color: white; }
        @media (max-width: 768px) {
            table, th, td { font-size: 12px; }
        }
    </style>
</head>
<body>

<h2>Registered Results</h2>

<div class="search-container">
    <form id="searchForm">
        <input type="text" id="searchInput" name="search" placeholder="Search by student name..." value="<?= htmlspecialchars($search) ?>">
        <button type="submit">Search</button>
    </form>
</div>

<?php if($result->num_rows === 0): ?>
    <p style="color:red; text-align:center;">No results found.</p>
<?php else: ?>
<table border="1" cellpadding="5" cellspacing="0">
    <tr>
        <th>Student</th>
        <th>Reg No</th>
        <th>Subject</th>
        <th>Exam Type</th>
        <th>Marks</th>
        <th>Grade</th>
        <th>Division</th>
        <th>Points</th>
        <th>Actions</th>
    </tr>

    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td><?= htmlspecialchars($row['regno']) ?></td>
        <td><?= htmlspecialchars($row['subject']) ?></td>
        <td><?= htmlspecialchars($row['exam_type']) ?></td>
        <td><?= htmlspecialchars($row['marks']) ?></td>
        <td><?= htmlspecialchars($row['grade']) ?></td>
        <td><?= htmlspecialchars($row['division']) ?></td>
        <td><?= htmlspecialchars($row['points']) ?></td>
        <td>
            <button class="action-btn edit-btn" data-id="<?= $row['detail_id'] ?>">Edit</button>
            <button class="action-btn delete-btn" data-id="<?= $row['detail_id'] ?>">Delete</button>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
<?php endif; ?>

<script>
// Handle delete
document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const id = this.getAttribute('data-id');
        if(confirm("Are you sure you want to delete this result?")) {
            fetch('ajax/delete_result.php?id=' + id)
            .then(res => res.json())
            .then(data => {
                if(data.success){
                    alert(data.success);
                    loadPage('manage_results.php');
                } else {
                    alert(data.error || "Failed to delete result");
                }
            })
            .catch(() => alert("Error deleting result"));
        }
    });
});

// Handle edit
document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const id = this.getAttribute('data-id');
        loadPage(`edit_result.php?id=${id}`);
    });
});

// Handle search submit via AJAX (no full reload)
const searchForm = document.getElementById('searchForm');
if (searchForm) {
    searchForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const q = document.getElementById('searchInput').value;
        loadPage('manage_results.php?search=' + encodeURIComponent(q));
    });
}
</script>

</body>
</html>

<?php 
$stmt->close();
$conn->close(); 
?>
