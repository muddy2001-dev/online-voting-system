<?php
include_once '../database.php';

$result = $conn->query("SELECT * FROM subjects ORDER BY id DESC LIMIT 10");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Registered Subjects</title>
    <style>
      
        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 20px;
        }

        table {
            width: 80%;
            margin: 0 auto 30px auto;
            border-collapse: collapse;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
        }

        th {
             background-color: #2c3e50;
            color: #fff;
            text-transform: uppercase;
            font-size: 14px;
        }

        tr {
            background-color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #d6eaf8;
        }

        .action-btn {
            padding: 5px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }

        .edit-btn {
            background-color: #2ecc71;
            color: white;
            margin-right: 5px;
        }

        .delete-btn {
            background-color: #e74c3c;
            color: white;
        }

        @media (max-width: 768px) {
            table, th, td {
                font-size: 12px;
            }
        }
    </style>
</head>
<body>

<h2>Registered Subjects</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Subject Name</th>
        <th>Subject Teacher</th>
        
    </tr>

    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= htmlspecialchars($row['subject']) ?></td>
        <td><?= htmlspecialchars($row['teacher']) ?></td>
      
    </tr>
    <?php endwhile; ?>
</table>

<script>
function deleteSubject(id) {
    if (confirm("Are you sure you want to delete this subject?")) {
        fetch('ajax/delete_subject.php?id=' + id, { method: 'GET' })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert(data.success);
                location.reload(); // reload page after deletion
            } else if (data.error) {
                alert(data.error);
            }
        })
        .catch(() => alert("Error deleting subject"));
    }
}
</script>

</body>
</html>

<?php $conn->close(); ?>
