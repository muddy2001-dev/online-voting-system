<?php
include_once __DIR__ . '/../admin/database.php';

// Fetch current settings (only 1 row expected)
$settings = $conn->query("SELECT * FROM settings LIMIT 1")->fetch_assoc();
$voting_status = $settings['voting_status'] ?? 0; // 0 = Closed, 1 = Open
$results_released = $settings['results_released'] ?? 0; // 0 = Hidden, 1 = Released
?>
<div class="container">
  <h2>Manage Voting Settings</h2>
  <form id="votingSettingsForm">
    <div class="form-group">
      <label for="voting_status">Voting Status:</label>
      <select name="voting_status" id="voting_status">
        <option value="1" <?= $voting_status ? 'selected' : '' ?>>Open</option>
        <option value="0" <?= !$voting_status ? 'selected' : '' ?>>Closed</option>
      </select>
    </div>

    <div class="form-group">
      <label for="results_released">Results:</label>
      <select name="results_released" id="results_released">
        <option value="1" <?= $results_released ? 'selected' : '' ?>>Released</option>
        <option value="0" <?= !$results_released ? 'selected' : '' ?>>Hidden</option>
      </select>
    </div>

    <button type="submit">Save Settings</button>
  </form>

  <div id="votingMessage"></div>
</div>

<style>
/* Container & layout */
.container {
  max-width: 480px;
  margin: 40px auto;
  padding: 30px;
  background: linear-gradient(145deg, #ffffff, #f0f0f0);
  border-radius: 15px;
  box-shadow: 0 10px 20px rgba(0,0,0,0.1);
  transition: transform 0.2s;
}
.container:hover {
  transform: translateY(-3px);
}

/* Heading */
h3 {
  text-align: center;
  margin-bottom: 25px;
  font-family: 'Segoe UI', sans-serif;
  color: #2c3e50;
}

/* Form groups */
.form-group {
  margin-bottom: 20px;
}
label {
  display: block;
  margin-bottom: 8px;
  font-weight: 600;
  color: #34495e;
}
select {
  width: 100%;
  padding: 10px 12px;
  border-radius: 8px;
  border: 1px solid #ccc;
  background: #fff;
  font-size: 1rem;
  transition: border 0.2s, box-shadow 0.2s;
}
select:focus {
  border-color: #2c3e50;
  box-shadow: 0 0 5px rgba(44,62,80,0.3);
  outline: none;
}

/* Button */
button {
  width: 100%;
  padding: 12px;
  background: #2c3e50;
  background: linear-gradient(120deg, #2c3e50, #34495e);
  color: #fff;
  font-size: 1rem;
  font-weight: 600;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.2s ease-in-out;
  box-shadow: 0 5px 10px rgba(0,0,0,0.1);
}
button:hover {
  background: linear-gradient(120deg, #34495e, #2c3e50);
  box-shadow: 0 6px 12px rgba(0,0,0,0.15);
  transform: translateY(-2px);
}

/* Message area */
#votingMessage {
  margin-top: 15px;
  font-weight: 600;
  text-align: center;
  color: #e74c3c;
}
</style>
