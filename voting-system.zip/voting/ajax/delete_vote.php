<?php
session_start();
include_once __DIR__ . '/../admin/database.php';

$positions = [];
$message = ''; 
$selected_position = $_POST['position'] ?? '';

// Fetch all distinct positions
$result = $conn->query("SELECT DISTINCT position FROM candidates");
while ($row = $result->fetch_assoc()) {
    $positions[] = $row['position'];
}

// Handle delete request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // If position is empty
    if (!$selected_position) {
        $response = ['success' => false, 'message' => '⚠️ Please select a position.'];
    } else {
        $stmt = $conn->prepare("DELETE FROM votes WHERE position = ?");
        $stmt->bind_param("s", $selected_position);
        if ($stmt->execute()) {
            $response = ['success' => true, 'message' => "✅ All votes for position '$selected_position' have been deleted."];
        } else {
            $response = ['success' => false, 'message' => "❌ Failed to delete votes: " . $stmt->error];
        }
        $stmt->close();
    }

    // Detect AJAX request
    $isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    if ($isAjax) {
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    } else {
        $message = $response['message'];
    }
}
?>


<div>
    <h2 style="text-align:center;">Delete Votes by Position</h2>

    <form method="POST" id="deleteVoteForm">
        <label for="position">Select Position:</label>
        <select name="position" id="position">
            <option value="">-- Choose Position --</option>
            <?php foreach ($positions as $pos): ?>
                <option value="<?= htmlspecialchars($pos) ?>" <?= ($pos === $selected_position) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($pos) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button type="submit" name="delete">Delete Votes</button>
    </form>

    <?php if ($message): ?>
        <div class="message <?= strpos($message, '✅') === 0 ? 'success' : 'error' ?>">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>
</div>

<style>
form select, form button {
    padding: 10px;
    border-radius: 6px;
    border: 1px solid #ccc;
    width: 100%;
    margin-bottom: 15px;
}
form button {
    background: #dc3545;
    color: white;
    border: none;
    cursor: pointer;
}
form button:hover {
    background: #c82333;
}
.message {
    margin-top: 20px;
    padding: 15px;
    border-radius: 6px;
    text-align:center;
}
.success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
.error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
</style>
