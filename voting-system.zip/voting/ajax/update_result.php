<?php
include_once __DIR__ . '/../admin/database.php';

header('Content-Type: application/json'); // ✅ force JSON

$response = [];

$id       = intval($_POST['id'] ?? 0);
$marks    = intval($_POST['marks'] ?? 0);
$grade    = trim($_POST['grade'] ?? '');
$division = trim($_POST['division'] ?? '');
$points   = floatval($_POST['points'] ?? 0);

if($id <= 0 || $grade === '' || $division === '' || $marks < 0){
    $response['error'] = "All fields are required.";
} else {
    // 1) Update result_details
    $stmt = $conn->prepare("
        UPDATE result_details
        SET grade=?, division=?, points=?
        WHERE id=?
    ");
    $stmt->bind_param("ssdi", $grade, $division, $points, $id);
    $ok1 = $stmt->execute();
    if(!$ok1){
        $response['error'] = "Details update failed: " . $stmt->error;
    }
    $stmt->close();

    // 2) Update marks in results (need result_id)
    if(!isset($response['error'])){
        $stmt2 = $conn->prepare("SELECT result_id FROM result_details WHERE id=?");
        $stmt2->bind_param("i", $id);
        $stmt2->execute();
        $stmt2->bind_result($result_id);
        $stmt2->fetch();
        $stmt2->close();

        if($result_id){
            $stmt3 = $conn->prepare("UPDATE results SET marks=? WHERE id=?");
            $stmt3->bind_param("ii", $marks, $result_id);
            if($stmt3->execute()){
                $response['success'] = "Result updated successfully.";
            } else {
                $response['error'] = "Marks update failed: " . $stmt3->error;
            }
            $stmt3->close();
        } else {
            $response['error'] = "Invalid result ID.";
        }
    }
}

$conn->close();
echo json_encode($response);
?>
