<?php
session_start();
include_once __DIR__ . '/../admin/database.php';

$positions = [];
$selected_position = $_POST['position'] ?? '';

// Fetch all distinct positions
$result = $conn->query("SELECT DISTINCT position FROM candidates");
while ($row = $result->fetch_assoc()) {
    $positions[] = $row['position'];
}

// Admin sees results regardless of release status
$results = [];
if ($selected_position) {
    $stmt = $conn->prepare("
        SELECT c.id, c.name, c.photo, COUNT(v.id) AS votes
        FROM candidates c
        LEFT JOIN votes v ON c.id = v.candidate_id
        WHERE c.position = ?
        GROUP BY c.id, c.name, c.photo
        ORDER BY votes DESC, c.name ASC
    ");
    $stmt->bind_param("s", $selected_position);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $results[] = $row;
    }
    $stmt->close();
}
?>

<div>
    <h2 style="text-align:center;">View Voting Results (Admin)</h2>

    <form method="POST" id="adminResultsForm">
        <label for="position">Select Position:</label>
        <select name="position" id="position">
            <option value="">-- Choose Position --</option>
            <?php foreach ($positions as $pos): ?>
                <option value="<?= htmlspecialchars($pos) ?>" <?= ($pos === $selected_position) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($pos) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <noscript><button type="submit">View Results</button></noscript>
    </form>

    <?php if ($selected_position): ?>
        <?php if ($results): ?>
            <table class="results-table">
                <thead>
                    <tr>
                        <th>Candidate</th>
                        <th>Photo</th>
                        <th>Votes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td>
                                <?php if ($row['photo'] && file_exists($row['photo'])): ?>
                                    <img src="<?= htmlspecialchars($row['photo']) ?>" class="candidate-photo" alt="<?= htmlspecialchars($row['name']) ?>" />
                                <?php else: ?>
                                    <span style="color:#999;">No photo</span>
                                <?php endif; ?>
                            </td>
                            <td><?= (int)$row['votes'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No candidates or votes found for this position.</p>
        <?php endif; ?>
    <?php endif; ?>
</div>

<style>
.results-table {
    max-width: 600px;
    margin: 20px auto;
    border-collapse: collapse;
    width: 100%;
    background: white;
    border-radius: 10px;
    box-shadow: 0 0 15px rgba(0,0,0,0.1);
    overflow: hidden;
}
.results-table th, .results-table td {
    padding: 12px 15px;
    border-bottom: 1px solid #ddd;
    text-align: left;
}
.results-table th {
   background-color: #2c3e50;
    color: white;
}
.candidate-photo {
    width: 50px;
    height: 50px;
    object-fit: cover;
    border-radius: 6px;
}
form select {
    padding: 10px;
    border-radius: 6px;
    border: 1px solid #ccc;
    width: 100%;
    margin-bottom: 15px;
}
</style>
