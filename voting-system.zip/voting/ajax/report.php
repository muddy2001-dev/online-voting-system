<?php
session_name("student_session");
session_start();

if (!isset($_SESSION['student_id'])) {
    header("Location: student-login.php");
    exit();
}

include_once __DIR__ . '/../database.php';

// Fetch student info
$studentStmt = $conn->prepare("SELECT id, name, regno, division, points FROM students WHERE id = ?");
$studentStmt->bind_param("i", $_SESSION['student_id']);
$studentStmt->execute();
$studentRes = $studentStmt->get_result();
$student = $studentRes->fetch_assoc();

// Fetch results with subject names and exam types
$sql = "SELECT r.marks, r.id AS result_id, s.subject, rd.exam_type, rd.grade
        FROM results r
        LEFT JOIN result_details rd ON r.id = rd.result_id
        INNER JOIN subjects s ON r.subject_id = s.id
        WHERE r.student_id = ?
        ORDER BY s.subject ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['student_id']);
$stmt->execute();
$res = $stmt->get_result();

// Organize results by exam type
$resultsByExam = [];
while ($row = $res->fetch_assoc()) {
    $examType = $row['exam_type'] ?? 'General';
    $resultsByExam[$examType][] = $row;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>My Results Report</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background-color: #f2f5f7; margin:0; padding:20px; }
        .navbar { background-color:#2c3e50; color: white; display: flex; justify-content: space-between; padding: 10px 15px; align-items: center; border-radius: 0 0 10px 10px;}
        .navbar .logo { font-size: 20px; font-weight: bold; }
        .navbar button { background: #3498db; border: none; padding: 5px 12px; color: #fff; cursor: pointer; border-radius: 5px; }
        h2, h3 { text-align: center; color: #333; }
        p.summary { text-align:center; font-size:1em; color:#555; }
        table { border-collapse: collapse; width: 80%; margin: 15px auto 40px auto; border-radius:10px; overflow:hidden; box-shadow:0 2px 6px rgba(0,0,0,0.1);}
        th, td { padding: 10px; border: 1px solid #ccc; text-align: center; }
        th { background-color: #3498db; color: #fff; }
        tr:nth-child(even) { background-color: #f9f9f9; }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="logo">SRMS</div>
    <button onclick="window.history.back()">Back</button>
</nav>

<h2>Results Report</h2>
<p class="summary"><strong>Student:</strong> <?= htmlspecialchars($student['name']) ?> (<?= htmlspecialchars($student['regno']) ?>) | 
<strong>Division:</strong> <?= htmlspecialchars($student['division'] ?? 'Not Calculated') ?> | 
<strong>Points:</strong> <?= htmlspecialchars($student['points'] ?? 0) ?></p>

<?php if ($resultsByExam): ?>
    <?php foreach($resultsByExam as $exam => $results): ?>
        <h3>Exam Type: <?= htmlspecialchars($exam) ?></h3>
        <table>
            <tr>
                <th>Subject</th>
                <th>Marks</th>
                <th>Grade</th>
            </tr>
            <?php foreach($results as $r): ?>
            <tr>
                <td><?= htmlspecialchars($r['subject']) ?></td>
                <td><?= htmlspecialchars($r['marks']) ?></td>
                <td><?= htmlspecialchars($r['grade'] ?? '-') ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    <?php endforeach; ?>
<?php else: ?>
    <p style="text-align:center;">No results available yet.</p>
<?php endif; ?>

</body>
</html>
