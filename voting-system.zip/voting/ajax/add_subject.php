<?php
session_start();
include_once __DIR__ . '/../database.php';

// Initialize messages
$success = '';
$error = '';

// Handle POST request only
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $subject = trim($_POST["subject"] ?? '');
    $teacher = trim($_POST["teacher"] ?? '');

    if ($subject !== '' && $teacher !== '') {
        $stmt = $conn->prepare("INSERT INTO subjects (subject, teacher) VALUES (?, ?)");
        if ($stmt) {
            $stmt->bind_param("ss", $subject, $teacher);
            if ($stmt->execute()) {
                $success = "✅ Subject added successfully!";
            } else {
                $error = "❌ Insert failed: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $error = "❌ Prepare failed: " . $conn->error;
        }
    } else {
        $error = "⚠️ Please fill in both subject and teacher.";
    }

    // Return JSON response only for POST
    echo json_encode(['success' => $success, 'error' => $error]);
    exit; // Stop script to avoid loading form HTML on POST
}
?>

<style>
    
    * { box-sizing: border-box; }
    #faqForm {
        background: white;
        padding: 30px 40px;
        max-width: 600px;
        width: 100%;
        border-radius: 12px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        margin-bottom: 20px;
    }
    #faqForm h2 {
        color: #007bff;
        text-align: center;
    }
    #faqForm label {
        font-weight: 600;
        margin-top: 15px;
        display: block;
    }
    #faqForm textarea {
        width: 100%;
        padding: 12px;
        border-radius: 6px;
        border: 1px solid #ccc;
        margin-top: 5px;
        resize: vertical;
    }
    #faqForm button {
        margin-top: 20px;
       background-color: #2c3e50;
        color: white;
        padding: 12px 20px;
        border: none;
        border-radius: 6px;
        width: 100%;
        cursor: pointer;
    }
    #faqForm button:hover {
        background: #0056b3;
    }
    .msg {
        margin-top: 15px;
        padding: 12px;
        border-radius: 6px;
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }
    .err {
        margin-top: 15px;
        padding: 12px;
        border-radius: 6px;
        background: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
    h3 { color: #007bff; text-align: center; }
    .form-container {
    display: flex;
    justify-content: center;  /* horizontally center */
    align-items: flex-start;  /* vertical alignment from top */
    padding: 30px;            /* optional spacing from top */
    width: 100%;
}

#faqForm {
    background: white;
    padding: 30px 40px;
    max-width: 600px;
    width: 100%;
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
}

</style>

<div class="form-container">
    <form id="faqForm">
        <h3>Register A new Subject</h3>
        <label for="subject">Subject Name</label>
        <textarea name="subject" id="subject" rows="1" placeholder="Type the subject name (e.g English)" required></textarea>

        <label for="teacher">Subject Teacher</label>
        <textarea name="teacher" id="teacher" rows="1" placeholder="Type the subject Teacher (e.g Mr. Bakari)" required></textarea>

        <button type="submit">➕ Add Subject</button>
        <div id="responseMessage"></div>
    </form>

    
</div>



