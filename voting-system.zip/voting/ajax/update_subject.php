<?php
include_once __DIR__ . '/../admin/database.php';


$response = [];

$id      = intval($_POST['id'] ?? 0);
$subject   = trim($_POST['subject'] ?? '');
$teacher  = trim($_POST['teacher'] ?? '');
;

if ($id <= 0 || empty($subject) || empty($teacher)){
    $response['error'] = "All fields are required.";
} else {
    $stmt = $conn->prepare("UPDATE subjects SET subject=?, teacher=? WHERE id=?");
    $stmt->bind_param("ssi", $subject, $teacher, $id);

    if ($stmt->execute()) {
        $response['success'] = "Subject updated successfully.";
    } else {
        $response['error'] = "Failed to update subject.";
    }
    $stmt->close();
}

$conn->close();
echo json_encode($response);
?>
