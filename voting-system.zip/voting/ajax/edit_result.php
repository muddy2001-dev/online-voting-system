<?php
include_once '../database.php';

$id = intval($_GET['id'] ?? 0);

$stmt = $conn->prepare("
    SELECT r.id as result_id, r.student_id, r.subject_id, r.marks,
           rd.id as detail_id, rd.exam_type, rd.grade, rd.division, rd.points,
           s.subject, st.name
    FROM results r
    INNER JOIN result_details rd ON r.id = rd.result_id
    INNER JOIN subjects s ON r.subject_id = s.id
    INNER JOIN students st ON r.student_id = st.id
    WHERE rd.id = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<p style='color:red; text-align:center;'>Result not found.</p>";
    exit;
}

$row = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<h2>Edit Result</h2>
   <style>
       

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 20px;
        }

        form {
            max-width: 500px;
            margin: 0 auto;
            background-color: #fff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            color: #34495e;
        }

        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 6px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        button {
            background-color: #27ae60;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            width: 100%;
        }

        button:hover {
            background-color: #1e8449;
        }

        #editResponse {
            text-align: center;
            margin-top: 15px;
            font-weight: bold;
        }
    </style>

<form id="editResultForm">
    <input type="hidden" name="id" value="<?= $row['detail_id'] ?>">

    <p>Student: <span style="color:red;font-weight:bold;"> <?= htmlspecialchars($row['name']) ?></span></p>
    <p>Subject:<span style="color:red;font-weight:bold;"> <?= htmlspecialchars($row['subject']) ?></span></p>
    <p>Exam Type:<span style="color:red;font-weight:bold;"> <?= htmlspecialchars($row['exam_type']) ?></span></p>

    <label>Marks:</label>
    <input type="number" name="marks" value="<?= $row['marks'] ?>" required>

    <label>Grade:</label>
    <input type="text" name="grade" value="<?= htmlspecialchars($row['grade']) ?>" required>

    <label>Division:</label>
    <input type="text" name="division" value="<?= htmlspecialchars($row['division']) ?>" required>

    <label>Points:</label>
    <input type="number" name="points" value="<?= $row['points'] ?>" required>

    <button type="submit">Update Result</button>
    <div id="editResponse"></div>
</form>



<script>
document.getElementById("editResultForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const formData = new FormData(this);

    fetch("ajax/update_result.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        const msg = document.getElementById("editResponse");
        if (data.success) {
            msg.innerHTML = `<span style='color:green;'>${data.success}</span>`;
            setTimeout(() => loadPage('manage_results.php'), 1000);
        } else if (data.error) {
            msg.innerHTML = `<span style='color:red;'>${data.error}</span>`;
        }
    })
    .catch(() => alert("Error updating result"));
});
</script>
