<?php
include_once __DIR__ . '/../admin/database.php';


$id = intval($_GET['id']);
$response = [];

if ($id > 0) {
    $stmt = $conn->prepare("DELETE FROM voters WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $response['success'] = "Voter deleted successfully.";
    } else {
        $response['error'] = "Failed to delete Voter.";
    }
    $stmt->close();
} else {
    $response['error'] = "Invalid voter ID.";
}

$conn->close();
echo json_encode($response);
?>
