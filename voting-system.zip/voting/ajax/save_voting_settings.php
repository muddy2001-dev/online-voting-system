<?php
include_once __DIR__ . '/../admin/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $voting_status = isset($_POST['voting_status']) ? (int)$_POST['voting_status'] : 0;
    $results_released = isset($_POST['results_released']) ? (int)$_POST['results_released'] : 0;

    $stmt = $conn->prepare("UPDATE settings SET voting_status=?, results_released=? WHERE id=1");
    $stmt->bind_param("ii", $voting_status, $results_released);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Settings updated successfully!"]);
    } else {
        echo json_encode(["error" => "Failed to update settings"]);
    }
    exit;
}
