<?php
session_start();
include_once __DIR__ . '/../database.php';

// Function to calculate grade
function calculateGrade($marks) {
    if ($marks >= 0 && $marks <= 29) return 'F';
    if ($marks >= 30 && $marks <= 39) return 'D';
    if ($marks >= 40 && $marks <= 64) return 'C';
    if ($marks >= 65 && $marks <= 79) return 'B';
    if ($marks >= 80 && $marks <= 100) return 'A';
    return 'Invalid';
}

function gradeToPoints($grade) {
    switch($grade) {
        case 'A': return 1;
        case 'B': return 2;
        case 'C': return 3;
        case 'D': return 4;
        case 'F': return 7;
        default: return 7; // Fail if unknown
    }
}

function calculateDivision($student_id, $exam_type, $conn) {
    $stmt = $conn->prepare("
        SELECT rd.grade 
        FROM results r 
        INNER JOIN result_details rd ON r.id = rd.result_id 
        WHERE r.student_id = ? AND rd.exam_type = ?
    ");
    $stmt->bind_param("is", $student_id, $exam_type);
    $stmt->execute();
    $res = $stmt->get_result();

    $points = [];
    while ($row = $res->fetch_assoc()) {
        $points[] = gradeToPoints($row['grade']);
    }
    $stmt->close();

    if (count($points) < 7) return ['division'=>'Division 0','points'=>0];

    sort($points); // Best subjects first
    $bestSeven = array_slice($points, 0, 7);
    $totalPoints = array_sum($bestSeven);

    if ($totalPoints >= 7 && $totalPoints <= 17) $div = 'Division I';
    elseif ($totalPoints >= 18 && $totalPoints <= 21) $div = 'Division II';
    elseif ($totalPoints >= 22 && $totalPoints <= 25) $div = 'Division III';
    elseif ($totalPoints >= 26 && $totalPoints <= 33) $div = 'Division IV';
    else $div = 'Division 0';

    return ['division'=>$div,'points'=>$totalPoints];
}

// Handle POST to save results
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = intval($_POST['student'] ?? 0);
    $marks_data = $_POST['marks'] ?? [];
    $exam_type = trim($_POST['exam_type'] ?? '');

    if ($student_id <= 0 || empty($marks_data) || $exam_type === '') {
        echo json_encode(['error' => 'Invalid input']);
        exit;
    }

    foreach ($marks_data as $subject_id => $marks) {
        $subject_id = intval($subject_id);
        $marks = intval($marks);
        $grade = calculateGrade($marks);

        // Insert/update results
        $stmt = $conn->prepare("
            INSERT INTO results (student_id, subject_id, marks, exam_type)
            VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE marks = VALUES(marks)
        ");
        $stmt->bind_param("iiis", $student_id, $subject_id, $marks, $exam_type);
        $stmt->execute();
        $result_id = $stmt->insert_id;
        $stmt->close();

        if ($result_id == 0) {
            $res_stmt = $conn->prepare("
                SELECT id FROM results WHERE student_id=? AND subject_id=? AND exam_type=?
            ");
            $res_stmt->bind_param("iis", $student_id, $subject_id, $exam_type);
            $res_stmt->execute();
            $res_stmt->bind_result($result_id);
            $res_stmt->fetch();
            $res_stmt->close();
        }

        // Insert/update result_details with grade only
        $stmt2 = $conn->prepare("
            INSERT INTO result_details (result_id, exam_type, grade)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE grade=VALUES(grade)
        ");
        $stmt2->bind_param("iss", $result_id, $exam_type, $grade);
        $stmt2->execute();
        $stmt2->close();
    }

    // ✅ Calculate division and points
    $divData = calculateDivision($student_id, $exam_type, $conn);

    // Fetch all result_details IDs for this student and exam type
    $stmt_fetch = $conn->prepare("
        SELECT rd.id 
        FROM result_details rd
        INNER JOIN results r ON rd.result_id = r.id
        WHERE r.student_id = ? AND rd.exam_type = ?
    ");
    $stmt_fetch->bind_param("is", $student_id, $exam_type);
    $stmt_fetch->execute();
    $res_fetch = $stmt_fetch->get_result();
    $result_detail_ids = [];
    while ($row = $res_fetch->fetch_assoc()) {
        $result_detail_ids[] = $row['id'];
    }
    $stmt_fetch->close();

    // Update each result_details row with division and points
    if (!empty($result_detail_ids)) {
        $stmt_update = $conn->prepare("
            UPDATE result_details 
            SET division = ?, points = ? 
            WHERE id = ?
        ");
        foreach ($result_detail_ids as $rd_id) {
            $stmt_update->bind_param("sii", $divData['division'], $divData['points'], $rd_id);
            $stmt_update->execute();
        }
        $stmt_update->close();
    }

    echo json_encode(['success' => "Results saved successfully!"]);
    exit;
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Add Results</title>
<style>
<style>
    body {
        font-family: 'Segoe UI', Arial, sans-serif;
        background: #f4f6f9;
        margin: 0;
        padding: 20px;
    }

    h3 {
        text-align: center;
        color: #333;
        margin-bottom: 25px;
    }

    .form-container {
        max-width: 600px;
        margin: auto;
        background: #fff;
        padding: 25px 30px;
        border-radius: 10px;
        box-shadow: 0px 4px 10px rgba(0,0,0,0.1);
    }

    label {
        display: block;
        margin-top: 15px;
        font-weight: 600;
        color: #444;
    }

    select, input[type=number] {
        width: 100%;
        padding: 10px;
        margin-top: 8px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 14px;
        transition: border-color 0.2s;
    }

    select:focus, input[type=number]:focus {
        border-color: #007bff;
        outline: none;
    }

    #subjectsContainer {
        margin-top: 20px;
        background: #fafafa;
        padding: 15px;
        border-radius: 8px;
        border: 1px solid #ddd;
    }

    #subjectsContainer h4 {
        margin-bottom: 15px;
        color: #333;
    }

    #subjectsInputs div {
        margin-bottom: 12px;
    }

    button {
        margin-top: 15px;
        padding: 12px 20px;
        border: none;
        border-radius: 6px;
        font-size: 15px;
        cursor: pointer;
        transition: 0.3s;
    }

    button[type=submit] {
        background-color: #007bff;
        color: #fff;
    }

    button[type=submit]:hover {
        background-color: #0056b3;
    }

    #responseMessage {
        margin-top: 20px;
        font-weight: 600;
        text-align: center;
    }

    #responseMessage div {
        padding: 10px;
        border-radius: 6px;
    }

    #responseMessage .success {
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }

    #responseMessage .error {
        background: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
</style>

</style>
</head>
<body>

  <div class="form-container">
        <h3>Add Student Results</h3>

        <label for="classSelect">Select Class</label>
        <select id="classSelect" required>
            <option value="">-- Select Class --</option>
            <option value="Form 1">Form 1</option>
            <option value="Form 2">Form 2</option>
            <option value="Form 3">Form 3</option>
            <option value="Form 4">Form 4</option>
        </select>

        <label for="sectionSelect">Select Section</label>
        <select id="sectionSelect" disabled required>
            <option value="">-- Select Section --</option>
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="C">C</option>
        </select>

        <label for="studentSelect">Select Student</label>
        <select id="studentSelect" disabled required>
            <option value="">-- Select Student --</option>
        </select>

        <label for="examType">Examination Type</label>
        <select id="examType" name="exam_type" form="resultsForm" required>
            <option value="">-- Select Exam Type --</option>
            <option value="Mid Term">Mid Term</option>
            <option value="Final">Final</option>
            <option value="Other">Other</option>
        </select>

        <div id="subjectsContainer" style="display:none;">
            <h4>Enter Marks (0-100)</h4>
            <form id="resultsForm">
                <div id="subjectsInputs"></div>
                <button type="submit">Save Results</button>
            </form>
        </div>

        <div id="responseMessage"></div>
    </div>

<script>
// Enable section select only after class is chosen
document.getElementById('classSelect').addEventListener('change', function() {
    const classVal = this.value;
    const sectionSelect = document.getElementById('sectionSelect');
    const studentSelect = document.getElementById('studentSelect');
    const subjectsContainer = document.getElementById('subjectsContainer');
    const subjectsInputs = document.getElementById('subjectsInputs');

    sectionSelect.value = '';
    studentSelect.innerHTML = '<option value="">-- Select Student --</option>';
    studentSelect.disabled = true;
    subjectsContainer.style.display = 'none';
    subjectsInputs.innerHTML = '';

    if (classVal) {
        sectionSelect.disabled = false;
    } else {
        sectionSelect.disabled = true;
    }
});

// Fetch students when section is selected
document.getElementById('sectionSelect').addEventListener('change', function() {
    const classVal = document.getElementById('classSelect').value;
    const sectionVal = this.value;
    const studentSelect = document.getElementById('studentSelect');
    const subjectsContainer = document.getElementById('subjectsContainer');
    const subjectsInputs = document.getElementById('subjectsInputs');

    studentSelect.innerHTML = '<option>Loading...</option>';
    studentSelect.disabled = true;
    subjectsContainer.style.display = 'none';
    subjectsInputs.innerHTML = '';

    if (!classVal || !sectionVal) {
        studentSelect.innerHTML = '<option value="">-- Select Student --</option>';
        studentSelect.disabled = true;
        return;
    }

    fetch(`ajax/fetch_students.php?class=${encodeURIComponent(classVal)}&section=${encodeURIComponent(sectionVal)}`)
    .then(res => res.json())
    .then(data => {
        studentSelect.innerHTML = '<option value="">-- Select Student --</option>';
        if (data.length > 0) {
            data.forEach(stu => {
                const opt = document.createElement('option');
                opt.value = stu.id;
                opt.textContent = stu.name + ' (' + stu.regno + ')';
                studentSelect.appendChild(opt);
            });
            studentSelect.disabled = false;
        } else {
            studentSelect.innerHTML = '<option value="">No students found</option>';
            studentSelect.disabled = true;
        }
    })
    .catch(() => {
        studentSelect.innerHTML = '<option value="">Error loading students</option>';
        studentSelect.disabled = true;
    });
});

// Fetch subjects when student is selected
document.getElementById('studentSelect').addEventListener('change', function() {
    const studentId = this.value;
    const subjectsContainer = document.getElementById('subjectsContainer');
    const subjectsInputs = document.getElementById('subjectsInputs');

    subjectsInputs.innerHTML = '';
    subjectsContainer.style.display = 'none';

    if (!studentId) return;

    fetch('ajax/fetch_subjects.php')
    .then(res => res.json())
    .then(subjects => {
        if (subjects.length === 0) {
            subjectsInputs.innerHTML = '<p>No subjects found. Please add subjects first.</p>';
            subjectsContainer.style.display = 'block';
            return;
        }
        subjects.forEach(subject => {
            const div = document.createElement('div');
            div.style.marginBottom = '10px';
            div.innerHTML = `
                <label>${subject.subject} (${subject.teacher}):</label>
                <input type="number" name="marks[${subject.id}]" min="0" max="100" required placeholder="0-100" />
            `;
            subjectsInputs.appendChild(div);
        });
        subjectsContainer.style.display = 'block';
    })
    .catch(() => {
        subjectsInputs.innerHTML = '<p>Error loading subjects</p>';
        subjectsContainer.style.display = 'block';
    });
});

// Submit results via AJAX
document.getElementById('resultsForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const studentId = document.getElementById('studentSelect').value;
    const examType = document.getElementById('examType').value;

    if (!studentId) {
        alert('Please select a student');
        return;
    }
    if (!examType) {
        alert('Please select an exam type');
        return;
    }

    const formData = new FormData(this);
    formData.append('student', studentId);
    formData.append('exam_type', examType);

    fetch('ajax/add_results.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        const msg = document.getElementById('responseMessage');
        if (data.success) {
            msg.innerHTML = `<div style="color:green;">${data.success}</div>`;
            this.reset();
            document.getElementById('classSelect').value = '';
            document.getElementById('sectionSelect').value = '';
            const studentSelect = document.getElementById('studentSelect');
            studentSelect.innerHTML = '<option value="">-- Select Student --</option>';
            studentSelect.disabled = true;
            document.getElementById('subjectsContainer').style.display = 'none';
        } else if (data.error) {
            msg.innerHTML = `<div style="color:red;">${data.error}</div>`;
        }
    })
    .catch(() => alert('Failed to save results'));
});
</script>

</body>
</html>
