<?php
session_start();
include_once __DIR__ . '/../database.php';

// Initialize filters
$class = $_GET['class'] ?? '';
$section = $_GET['section'] ?? '';

// Fetch students for selected class and section
$students = [];
if ($class && $section) {
    $stmt = $conn->prepare("SELECT id, name, regno FROM students WHERE class=? AND section=? ORDER BY name ASC");
    $stmt->bind_param("ss", $class, $section);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $students[] = $row;
    }
    $stmt->close();
}

// Fetch results for all students
$all_results = [];
if ($students) {
    $student_ids = array_column($students, 'id');
    $ids_placeholder = implode(',', array_fill(0, count($student_ids), '?'));
    $types = str_repeat('i', count($student_ids));

    $stmt_sql = "
        SELECT r.student_id, r.subject_id, r.marks, 
               rd.exam_type, rd.grade, rd.division, rd.points,
               s.subject, st.name, st.regno
        FROM results r
        INNER JOIN result_details rd ON r.id = rd.result_id
        INNER JOIN subjects s ON r.subject_id = s.id
        INNER JOIN students st ON r.student_id = st.id
        WHERE r.student_id IN ($ids_placeholder)
        ORDER BY st.name, rd.exam_type, s.subject
    ";

    $stmt = $conn->prepare($stmt_sql);
    $stmt->bind_param($types, ...$student_ids);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $all_results[$row['student_id']][$row['exam_type']][] = $row;
    }
    $stmt->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Student Results</title>
<style>

h3 {
    text-align:center;
    margin-bottom:20px;
    color:#2c3e50;
}
form {
    text-align:center;
    margin-bottom:30px;
}
label {
    display:inline-block;
    margin: 0 5px 10px 0;
    font-weight:600;
}
select {
    padding:6px 10px;
    margin-right:10px;
    border-radius:6px;
    border:1px solid #ccc;
}
button {
    padding:6px 15px;
    background:#2980b9;
    color:white;
    border:none;
    border-radius:6px;
    cursor:pointer;
}
button:hover {
    background:#1f618d;
}
.student-card {
    background:white;
    margin-bottom:25px;
    padding:20px;
    border-radius:10px;
    box-shadow:0 3px 10px rgba(0,0,0,0.1);
}
.student-card h4 {
    margin-top:0;
    color:#34495e;
}
.student-card p {
    margin:5px 0;
    font-size:14px;
    color:#555;
}
table {
    border-collapse: collapse;
    width:100%;
    margin-top:10px;
    border-radius:6px;
    overflow:hidden;
}
th, td {
    padding:10px;
    border:1px solid #ccc;
    text-align:center;
}
th {
    background:#2980b9;
    color:white;
}
td {
    background:#fdfdfd;
}
</style>
</head>
<body>

<h3>View Student Results</h3>

<form method="GET" id="filterForm">
    <label for="class">Class:</label>
    <select name="class" id="class" required>
        <option value="">-- Select Class --</option>
        <option value="Form 1" <?= $class=='Form 1'?'selected':'' ?>>Form 1</option>
        <option value="Form 2" <?= $class=='Form 2'?'selected':'' ?>>Form 2</option>
        <option value="Form 3" <?= $class=='Form 3'?'selected':'' ?>>Form 3</option>
        <option value="Form 4" <?= $class=='Form 4'?'selected':'' ?>>Form 4</option>
    </select>

    <label for="section">Section:</label>
    <select name="section" id="section" required>
        <option value="">-- Select Section --</option>
        <option value="A" <?= $section=='A'?'selected':'' ?>>A</option>
        <option value="B" <?= $section=='B'?'selected':'' ?>>B</option>
        <option value="C" <?= $section=='C'?'selected':'' ?>>C</option>
    </select>

    <button type="submit">Filter</button>
</form>

<?php foreach($students as $stu): ?>
<div class="student-card">
    <h4><?= htmlspecialchars($stu['name']) ?> (<?= $stu['regno'] ?>)</h4>

    <?php if(isset($all_results[$stu['id']])): ?>
        <?php foreach($all_results[$stu['id']] as $examType => $results): ?>
            <p><strong>Exam Type:</strong> <?= htmlspecialchars($examType) ?> | 
               <strong>Division:</strong> <?= htmlspecialchars($results[0]['division']) ?> | 
               <strong>Points:</strong> <?= htmlspecialchars($results[0]['points']) ?></p>
               
            <table>
                <thead>
                    <tr>
                        <th>Subject</th>
                        <th>Marks</th>
                        <th>Grade</th>
                         
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($results as $r): ?>
                        <tr>
                            <td><?= htmlspecialchars($r['subject']) ?></td>
                            <td><?= $r['marks'] ?></td>
                            <td><?= $r['grade'] ?></td>
        

                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="color:red;">No results found for <?= htmlspecialchars($stu['name']) ?></p>
    <?php endif; ?>
</div>
<?php endforeach; ?>



</body>
</html>
