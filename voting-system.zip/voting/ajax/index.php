<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ajax Sidebar Layout</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>



    <!-- Content -->
    <div class="content" id="mainContent">
    <h3> <marquee>Welcome To Online Voting System</marquee></h3>

    <div class="dashboard-cards">
     
             <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_voters.php')">
               <div class="card">
                <div class="card-logo">📝</div>
                <strong>Registered Voters</strong>
            </div>
             </a>
               <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_candidate.php')">
               <div class="card">
                <div class="card-logo">🗓️</div>
                <strong>Registered Candidates</strong>
            </div>
             </a>

           <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_result.php')">
               <div class="card">
                <div class="card-logo">🗓️</div>
                <strong>Voting Results</strong>
            </div>
             </a>

         <a href="javascript:void(0);" class="card-link" onclick="loadPage('report_summary_votes.php')">
            <div class="card">
                <div class="card-logo">💳</div>
                <strong> Reports</strong>
            </div>
        </a>
    </div>
  </div>



</body>
</html>
