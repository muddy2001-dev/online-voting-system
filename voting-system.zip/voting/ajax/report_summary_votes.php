<?php
session_start();
include_once __DIR__ . '/../admin/database.php';

// Fetch all positions
$positions = [];
$result = $conn->query("SELECT DISTINCT position FROM candidates ORDER BY position ASC");
while ($row = $result->fetch_assoc()) {
    $positions[] = $row['position'];
}

// Fetch votes for all positions
$summary = [];
foreach ($positions as $pos) {
    $sql = "
        SELECT c.id, c.name, COUNT(v.id) AS votes
        FROM candidates c
        LEFT JOIN votes v ON c.id = v.candidate_id
        WHERE c.position = ?
        GROUP BY c.id, c.name
        ORDER BY votes DESC, c.name ASC
    ";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $pos);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $summary[$pos][] = $row;
    }
    $stmt->close();
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Voting Summary Report</title>
<style>
body { font-family: Arial, sans-serif; background:#f4f6f9; }
h2 { text-align:center; margin:20px 0; color:#2c3e50; }
.table-box {
    background:white;
    margin:20px auto;
    padding:20px;
    border-radius:10px;
    box-shadow:0 3px 10px rgba(0,0,0,0.1);
    max-width:800px;
}
table {
    border-collapse:collapse;
    width:100%;
    margin-top:10px;
}
th, td {
    border:1px solid #ccc;
    padding:10px;
    text-align:center;
}
th {
     background: #2c3e50;
    color:white;
}
.position-title {
    text-align:left;
    margin-top:30px;
    font-size:18px;
    font-weight:bold;
    color:#34495e;
}
</style>
</head>
<body>

<h2>Voting Summary Report (All Positions)</h2>

<div class="table-box">
    <?php if ($summary): ?>
        <?php foreach ($summary as $pos => $candidates): ?>
            <div class="position-title"><?= htmlspecialchars($pos) ?></div>
            <table>
                <thead>
                    <tr>
                        <th>Candidate</th>
                        <th>Total Votes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($candidates as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td><?= (int)$row['votes'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No votes or candidates found.</p>
    <?php endif; ?>
</div>

</body>
</html>
