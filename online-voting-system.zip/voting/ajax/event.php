<?php
include_once '../database.php';

// Fetch the latest notices (limit to 10 for performance)
$result = $conn->query("SELECT * FROM faqs ORDER BY created_at DESC LIMIT 10");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Upcoming Events</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 20px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .event-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }
        .event-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            width: 300px;
            padding: 20px;
            transition: transform 0.2s ease;
        }
        .event-card:hover {
            transform: translateY(-5px);
        }
        .event-title {
            font-size: 1.2em;
            font-weight: bold;
            color: #0056b3;
            margin-bottom: 10px;
        }
        .event-message {
            font-size: 0.95em;
            color: #555;
            margin-bottom: 15px;
        }
        .event-date {
            font-size: 0.85em;
            color: #999;
            text-align: right;
        }
    </style>
</head>
<body>

<h2>📅 Upcoming Events & Notices</h2>
<div class="event-container">
<?php while ($row = $result->fetch_assoc()): ?>
    <div class="event-card">
        <div class="event-title"><?php echo htmlspecialchars($row['tittle']); ?></div>
        <div class="event-message"><?php echo nl2br(htmlspecialchars($row['message'])); ?></div>
        <div class="event-date">🕒 <?php echo date("F j, Y", strtotime($row['created_at'])); ?></div>
    </div>
<?php endwhile; ?>
</div>

<?php $conn->close(); ?>
</body>
</html>
