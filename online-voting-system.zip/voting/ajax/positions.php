<?php
include_once __DIR__ . '/../admin/database.php';

header('Content-Type: application/json');

$positions = [];
$result = $conn->query("SELECT DISTINCT position FROM candidates ORDER BY position ASC");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $positions[] = $row['position'];
    }
}

echo json_encode(['positions' => $positions]);
