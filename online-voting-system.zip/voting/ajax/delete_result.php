<?php
include_once '../database.php';

$id = intval($_GET['id']);
$response = [];

if($id > 0){
    $stmt = $conn->prepare("DELETE FROM result_details WHERE id=?");
    $stmt->bind_param("i", $id);
    if($stmt->execute()){
        $response['success'] = "Result deleted successfully.";
    } else {
        $response['error'] = "Failed to delete result.";
    }
    $stmt->close();
} else {
    $response['error'] = "Invalid result ID.";
}

$conn->close();
echo json_encode($response);
?>
