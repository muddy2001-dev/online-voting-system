<?php
include_once '../database.php';

$result = $conn->query("SELECT * FROM students ORDER BY id DESC LIMIT 10");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Registered Students</title>
    <style>
      

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 20px;
        }

        table {
            width: 95%;
            margin: 0 auto 30px auto;
            border-collapse: collapse;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            padding: 12px 10px;
            text-align: center;
        }

        th {
            background-color: #3498db;
            color: #fff;
            text-transform: uppercase;
            font-size: 14px;
        }

        tr {
            background-color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #d6eaf8;
        }

        .action-btn {
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 13px;
        }

        .edit-btn {
            background-color: #2ecc71;
            color: white;
            margin-right: 5px;
        }

        .delete-btn {
            background-color: #e74c3c;
            color: white;
        }

        @media (max-width: 1024px) {
            table, th, td {
                font-size: 12px;
            }
        }

        @media (max-width: 768px) {
            table {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<h2>Registered Students</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Reg. Number</th>
        <th>Phone</th>
        <th>Gender</th>
        <th>Class</th>
        <th>Section</th>
        <th>Date Of Birth</th>
        <th>Registration Date</th>
       
    </tr>

    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td><?= htmlspecialchars($row['regno']) ?></td>
        <td><?= htmlspecialchars($row['phone']) ?></td>
        <td><?= htmlspecialchars($row['gender']) ?></td>
        <td><?= htmlspecialchars($row['class']) ?></td>
        <td><?= htmlspecialchars($row['section']) ?></td>
        <td><?= htmlspecialchars($row['dob']) ?></td>
        <td><?= htmlspecialchars($row['created_at']) ?></td>
        
    </tr>
    <?php endwhile; ?>
</table>

<script>
function deleteStudent(id) {
    if (confirm("Are you sure you want to delete this student?")) {
        fetch('ajax/delete_student.php?id=' + id, { method: 'GET' })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert(data.success);
                location.reload(); // reload page after deletion
            } else if (data.error) {
                alert(data.error);
            }
        })
        .catch(() => alert("Error deleting student"));
    }
}
</script>

</body>
</html>

<?php $conn->close(); ?>
