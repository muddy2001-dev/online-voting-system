<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ajax Sidebar Layout</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>



    <!-- Content -->
    <div class="content" id="mainContent">
     <h3>Welcome to Your Dashboard</h3>

    <div class="dashboard-cards">
        <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_studentss.php')">
               <div class="card">
                <div class="card-logo">📝</div>
                <strong>Registered Students</strong>
            </div>
             </a>

       <a href="javascript:void(0);" class="card-link" onclick="loadPage('manage_subjectss.php')">
               <div class="card">
                <div class="card-logo">📝</div>
                <strong>Registered Subjects</strong>
            </div>
             </a>
            <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_results.php')">
               <div class="card">
                <div class="card-logo">🗓️</div>
                <strong>Students Results</strong>
            </div>
             </a>

        <a href="update.php" class="card-link">
            <div class="card">
                <div class="card-logo">⚙️</div>
                <strong>Settings</strong>
            </div>
        </a>
    </div>
  </div>



</body>
</html>
