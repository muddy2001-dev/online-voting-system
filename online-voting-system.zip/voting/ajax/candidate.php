<?php
session_start();
include_once __DIR__ . '/../admin/database.php';


// Initialize messages
$success = '';
$error = '';

function generateRegNo() {
    return 'WSS-2025-' . str_pad(rand(0, 99999), 5, '0', STR_PAD_LEFT);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name     = trim($_POST["name"] ?? '');
    $phone    = trim($_POST["phone"] ?? '');
    $gender   = trim($_POST["gender"] ?? '');
    $dob      = trim($_POST["dob"] ?? '');
    $position = trim($_POST["position"] ?? '');
    $regno    = generateRegNo();

    // Photo upload
    $photoPath = "";
    if (!empty($_FILES['photo']['name'])) {
        $targetDir = "../uploads/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

        $photoPath = $targetDir . time() . "_" . basename($_FILES['photo']['name']);
        move_uploaded_file($_FILES['photo']['tmp_name'], $photoPath);
    }

    if ($name && $phone && $gender && $dob && $position) {
        $stmt = $conn->prepare("INSERT INTO candidates (name, position, photo, regno, phone, gender, dob) 
                                VALUES (?, ?, ?, ?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("sssssss", $name, $position, $photoPath, $regno, $phone, $gender, $dob);

            if ($stmt->execute()) {
                $success = "✅ Candidate Registered Successfully!";
            } else {
                $error = "❌ Registration failed: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $error = "❌ Prepare failed: " . $conn->error;
        }
    } else {
        $error = "⚠️ Please fill in all parts.";
    }

    echo json_encode(['success' => $success, 'error' => $error]);
    exit;
}
?>



<style>
    * { box-sizing: border-box; }
    #faqForm {
        background: white;
        padding: 30px 40px;
        max-width: 600px;
        width: 100%;
        border-radius: 12px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        margin-bottom: 20px;
    }
    #faqForm h2 {
        color: #007bff;
        text-align: center;
    }
    #faqForm label {
        font-weight: 600;
        margin-top: 15px;
        display: block;
    }
    #faqForm textarea {
        width: 100%;
        padding: 12px;
        border-radius: 6px;
        border: 1px solid #ccc;
        margin-top: 5px;
        resize: vertical;
    }
    #faqForm button {
        margin-top: 20px;
        background-color: #2c3e50;
        color: white;
        padding: 12px 20px;
        border: none;
        border-radius: 6px;
        width: 100%;
        cursor: pointer;
    }
    #faqForm button:hover {
        background: #0056b3;
    }
    .msg {
        margin-top: 15px;
        padding: 12px;
        border-radius: 6px;
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }
    .err {
        margin-top: 15px;
        padding: 12px;
        border-radius: 6px;
        background: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
    h3 { color: #007bff; text-align: center; }
    /* Style for radio buttons container */
#faqForm div {
  margin-top: 5px;
  margin-bottom: 15px;
}

/* Style radio labels for spacing and alignment */
#faqForm div label {
  margin-right: 20px;
  font-weight: normal;
  cursor: pointer;
  user-select: none;
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

/* Style for select dropdowns */
#faqForm select,
#faqForm input[type="date"] {
  width: 100%;
  padding: 12px;
  border-radius: 6px;
  border: 1px solid #ccc;
  margin-top: 5px;
  box-sizing: border-box;
  font-size: 1rem;
  font-family: inherit;
  appearance: none; /* Remove default arrow on some browsers */
  background: white url("data:image/svg+xml;charset=US-ASCII,%3Csvg width='10' height='7' viewBox='0 0 10 7' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 1L5 5L9 1' stroke='%23666' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E") no-repeat right 12px center;
  background-size: 10px 7px;
}

/* Focus style for selects and date */
#faqForm select:focus,
#faqForm input[type="date"]:focus {
  outline: none;
  border-color: #007bff;
  box-shadow: 0 0 5px rgba(0,123,255,0.5);
}

/* For consistent font in date picker placeholder */
#faqForm input[type="date"] {
  font-family: inherit;
}
.form-container {
    display: flex;
    justify-content: center;  /* horizontally center */
    align-items: flex-start;  /* vertical alignment from top */
    padding: 30px;            /* optional spacing from top */
    width: 100%;
}

#faqForm {
    background: white;
    padding: 30px 40px;
    max-width: 600px;
    width: 100%;
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
}

</style>
<div class="form-container">
<form id="faqForm">
    <h3>Candidate Registration</h3>

    <label for="name">Full Name</label>
    <textarea name="name" id="name" rows="1" placeholder="Type the name..." required></textarea>

    <label for="position">Position</label>
<textarea name="position" id="position" rows="1" placeholder="Type the position..." required></textarea>

<label for="photo">Photo</label>
<input type="file" name="photo" id="photo" accept="image/*">


  <label for="regno">Reg. Number</label>
<textarea name="regno" id="regno" rows="1" readonly placeholder="Auto-generated upon save"></textarea>
    
    <label for="phone">Phone</label>
    <textarea name="phone" id="phone" rows="1" placeholder="Type the phone (e.g 07xxxxxxxx)" required></textarea>

    <!-- GENDER RADIO BUTTONS -->
    <label>Gender</label>
    <div>
        <label><input type="radio" name="gender" value="Male" required> Male</label>
        <label><input type="radio" name="gender" value="Female" required> Female</label>
        <label><input type="radio" name="gender" value="Other" required> Other</label>
    </div>


   

    <!-- DOB DATE PICKER -->
    <label for="dob">Date Of Birth</label>
    <input type="date" name="dob" id="dob" required>

    <button type="submit">➕ Add Candidate</button>
    <div id="responseMessage"></div>
</form>


</div>
<script>
// Generate regno on page load for display purposes only
document.addEventListener("DOMContentLoaded", function() {
    let randomNum = String(Math.floor(Math.random() * 10000)).padStart(4, '0');
    document.getElementById("regno").value = "WSS-2025-" + randomNum;
});
</script>