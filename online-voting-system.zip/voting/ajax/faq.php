<?php
session_start();
include_once __DIR__ . '/../admin/database.php';


// Handle AJAX POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    header('Content-Type: application/json'); // Return JSON
    $response = ['success' => '', 'error' => ''];

    $tittle = trim($_POST['tittle'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($tittle !== '' && $message !== '') {
        $stmt = $conn->prepare("INSERT INTO faqs (tittle, message) VALUES (?, ?)");
        if ($stmt) {
            $stmt->bind_param("ss", $tittle, $message);
            if ($stmt->execute()) {
                $response['success'] = "✅ Message added successfully!";

                // Notify all students
                $students = $conn->query("SELECT id FROM voters");
                if ($students && $students->num_rows > 0) {
                    $notif_stmt = $conn->prepare("INSERT INTO notifications (student_id, message) VALUES (?, ?)");
                    $notif_msg = "📢 New Notice posted: " . $tittle;

                    while ($row = $students->fetch_assoc()) {
                        $sid = $row['id'];
                        $notif_stmt->bind_param("is", $sid, $notif_msg);
                        $notif_stmt->execute();
                    }
                    $notif_stmt->close();
                }

            } else {
                $response['error'] = "❌ Insert failed: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $response['error'] = "❌ Prepare failed: " . $conn->error;
        }
    } else {
        $response['error'] = "⚠️ Please fill in all fields!";
    }

    echo json_encode($response);
    exit; // Stop here for AJAX POST
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Post FAQ</title>
    <style>
        * { box-sizing: border-box; }
        .form-container {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 30px;
            width: 100%;
        }
        #faqForm {
            background: white;
            padding: 30px 40px;
            max-width: 600px;
            width: 100%;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }
        #faqForm h3 { color: #007bff; text-align: center; }
        #faqForm label {
            font-weight: 600;
            margin-top: 15px;
            display: block;
        }
        #faqForm textarea {
            width: 100%;
            padding: 12px;
            border-radius: 6px;
            border: 1px solid #ccc;
            margin-top: 5px;
            resize: vertical;
        }
        #faqForm button {
            margin-top: 20px;
            background-color: #2c3e50;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 6px;
            width: 100%;
            cursor: pointer;
        }
        #faqForm button:hover { background: #0056b3; }
        .msg, .err {
            margin-top: 15px;
            padding: 12px;
            border-radius: 6px;
        }
        .msg {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .err {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>

<div class="form-container">
<form id="faqForm">
    <h3>Post a New Message</h3>

    <label for="tittle">Tittle</label>
    <textarea name="tittle" id="tittle" rows="3" placeholder="Type the tittle..." required></textarea>

    <label for="message">Message</label>
    <textarea name="message" id="message" rows="5" placeholder="Provide the message..." required></textarea>

    <button type="submit">➕ Add Message</button>
    <div id="responseMessage"></div>
</form>
</div>

<script>
const form = document.getElementById('faqForm');
if(form) {
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(form);

    fetch('faq.php', { // same file handles AJAX
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(data => {
      const responseDiv = document.getElementById('responseMessage');
      if(data.success) {
        responseDiv.innerHTML = `<div class="msg">${data.success}</div>`;
        form.reset();
      } else if(data.error) {
        responseDiv.innerHTML = `<div class="err">${data.error}</div>`;
      }
    })
    .catch(err => {
      console.error("Fetch error:", err);
      alert('Failed to submit form (see console)');
    });
  });
}
</script>

</body>
</html>
