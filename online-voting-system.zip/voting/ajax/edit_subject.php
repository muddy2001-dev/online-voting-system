<?php
include_once '../database.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) {
    echo "<p style='color:red; text-align:center;'>Invalid subject ID.</p>";
    exit;
}

$stmt = $conn->prepare("SELECT * FROM subjects WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<p style='color:red; text-align:center;'>Subject not found.</p>";
    exit;
}

$row = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edit Subject</title>
    <style>
      

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 20px;
        }

        form {
            max-width: 450px;
            margin: 0 auto;
            background-color: #fff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            color: #34495e;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 6px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        button {
            background-color: #2980b9;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            width: 100%;
        }

        button:hover {
            background-color: #1f618d;
        }

        #editResponse {
            text-align: center;
            margin-top: 15px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>Edit Subject</h2>

<form id="editSubjectForm">
    <input type="hidden" name="id" value="<?= $row['id'] ?>">

    <label>Subject:</label>
    <input type="text" name="subject" value="<?= htmlspecialchars($row['subject']) ?>" required>

    <label>Teacher:</label>
    <input type="text" name="teacher" value="<?= htmlspecialchars($row['teacher']) ?>" required>

    <button type="submit">Update Subject</button>
</form>

<div id="editResponse"></div>

<script>
document.getElementById("editSubjectForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const formData = new FormData(this);

    fetch("ajax/update_subject.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        const msg = document.getElementById("editResponse");
        if (data.success) {
            msg.innerHTML = `<span style='color:green;'>${data.success}</span>`;
            setTimeout(() => {
                loadPage('manage_subjects.php'); // reload subjects list
            }, 1000);
        } else if (data.error) {
            msg.innerHTML = `<span style='color:red;'>${data.error}</span>`;
        }
    })
    .catch(() => alert("Error updating subject"));
});
</script>

</body>
</html>
