<?php
session_start();
include_once __DIR__ . '/../admin/database.php';



$message = "";

// Handle admin actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['start_voting'])) {
        $conn->query("UPDATE settings SET voting_status = 'open'");
        $message = "✅ Voting has been started.";
    } elseif (isset($_POST['stop_voting'])) {
        $conn->query("UPDATE settings SET voting_status = 'closed'");
        $message = "⛔ Voting has been stopped.";
    } elseif (isset($_POST['release_results'])) {
        $conn->query("UPDATE settings SET results_released = 1");
        $message = "📢 Results have been released.";
    }
}

// Fetch current status
$status = $conn->query("SELECT voting_status, results_released FROM settings LIMIT 1")->fetch_assoc();
$voting_status = $status['voting_status'] ?? 'closed';
$results_released = $status['results_released'] ?? 0;
?>

<div style="padding:20px; max-width:600px; margin:auto;">
    <h2 style="text-align:center;">🗳️ Manage Voting</h2>

    <?php if ($message): ?>
        <div style="padding:10px; background:#eef; margin-bottom:15px; border-radius:5px;">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <form id="manageVotingForm" method="POST" action="">
        <p><strong>Current Voting Status:</strong> <?= htmlspecialchars($voting_status) ?></p>
        <p><strong>Results Released:</strong> <?= $results_released ? "Yes" : "No" ?></p>

        <button type="submit" name="start_voting" style="padding:10px; margin:5px; background:green; color:white; border:none; border-radius:5px;">Start Voting</button>
        <button type="submit" name="stop_voting" style="padding:10px; margin:5px; background:red; color:white; border:none; border-radius:5px;">Stop Voting</button>
        <button type="submit" name="release_results" style="padding:10px; margin:5px; background:blue; color:white; border:none; border-radius:5px;">Release Results</button>
    </form>
</div>
