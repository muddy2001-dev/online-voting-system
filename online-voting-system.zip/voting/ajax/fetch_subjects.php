<?php
include_once __DIR__ . '/../database.php';

header('Content-Type: application/json');

$result = $conn->query("SELECT id, subject, teacher FROM subjects ORDER BY subject ASC");

$subjects = [];
while ($row = $result->fetch_assoc()) {
    $subjects[] = $row;
}

$conn->close();

echo json_encode($subjects);
