<?php
include_once '../database.php';

$id = intval($_GET['id']);
$response = [];

if ($id > 0) {
    $stmt = $conn->prepare("DELETE FROM subjects WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $response['success'] = "Subject deleted successfully.";
    } else {
        $response['error'] = "Failed to delete subject.";
    }
    $stmt->close();
} else {
    $response['error'] = "Invalid subject ID.";
}

$conn->close();
echo json_encode($response);
?>
