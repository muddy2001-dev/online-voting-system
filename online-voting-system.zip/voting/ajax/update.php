<?php
include_once __DIR__ . '/../admin/database.php';

session_name("admin_session");
session_start();

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['error' => 'Not logged in']);
    exit();
}

$userId = $_SESSION['admin_id'];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? '');
    $email = trim($_POST["email"] ?? '');
    $phone = trim($_POST["phone"] ?? '');

    if (!$name || !$email || !$phone) {
        echo json_encode(['error' => 'All fields are required']);
        exit();
    }

    $stmt = $conn->prepare("UPDATE admin SET name=?, email=?, phone=? WHERE id=?");
    $stmt->bind_param("sssi", $name, $email, $phone, $userId);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(['success' => 'Details updated successfully.']);
        } else {
            echo json_encode(['success' => 'No changes made (data may be the same).']);
        }
    } else {
        echo json_encode(['error' => 'Error: ' . $stmt->error]);
    }

    $stmt->close();
    exit();
}

// GET request: fetch data to fill form
$stmt = $conn->prepare("SELECT name, email, phone FROM admin WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc() ?? ['name'=>'', 'email'=>'', 'phone'=>''];
$stmt->close();
?>

<style>
body {
    font-family: 'Segoe UI', sans-serif;
    background: #f0f2f5;
    margin: 0;
    padding: 0;
    overflow: hidden; /* disables scrolling */
    height: 100vh;     /* make body fill the viewport */
}

.container {
    max-width: 450px;
    margin: 12px auto;
    background: white;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}

h3{
    text-align: center;
    color: #333;
}

label {
    display: block;
    margin-top: 15px;
    font-weight: 500;
}

input[type="text"], input[type="email"], input[type="tel"] {
    width: 100%;
    padding: 10px;
    border-radius: 5px;
    margin-top: 5px;
    border: 1px solid #ccc;
}

button {
    margin-top: 20px;
    width: 100%;
    padding: 12px;
    background-color: #2c3e50;
    color: white;
    border: none;
    font-size: 16px;
    border-radius: 5px;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

.message {
    margin-top: 15px;
    padding: 10px;
    border-radius: 5px;
    background-color: #f1f1f1;
    font-size: 15px;
    text-align: center;
}

.message strong {
    display: block;
}

@media (max-width: 500px) {
    .container {
        margin: 20px;
        padding: 20px;
    }
}

        .settings-options {
    max-width: 450px;       /* same width as container */
    margin: 20px auto 50px; /* space above and below, centered */
    display: flex;
    justify-content: space-between;
    gap: 15px;
}

.settings-options a {
    flex: 1;
    text-align: center;
    padding: 12px 0;
    background-color: #2c3e50;
    color: white;
    border-radius: 5px;
    text-decoration: none;
    font-weight: 600;
    cursor: pointer;
    transition: background-color 0.3s ease;
    user-select: none;
}

.settings-options a:hover {
    background-color: #0056b3;
}

@media (max-width: 500px) {
    .settings-options {
        flex-direction: column;
    }
    .settings-options a {
        flex: unset;
        margin-bottom: 10px;
    }
}
</style>

<div class="container">
    <h3>Update Your Details</h3>

    <form id="updateForm" method="post" autocomplete="off">
      <label>Full name</label>
      <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>

      <label>Email</label>
      <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>

      <label>Phone</label>
      <input type="tel" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" required>

      <button type="submit">Update Details</button>
         <div class="settings-options">
           
             <a href="javascript:void(0);" onclick="loadPage('change_password.php')">Change Password</a>
             <a href="delete_admin.php">Delete Account</a>

           
        </div>
      
    </form>

    <div class="message"></div>
</div>

<script>
document.getElementById('updateForm').addEventListener('submit', function(e) {
  e.preventDefault(); // prevent full page reload

  const form = e.target;
  const formData = new FormData(form);

  fetch('ajax/update.php', {
    method: 'POST',
    body: formData
  })
  .then(res => res.json())
  .then(data => {
    const messageDiv = document.querySelector('.message');
    if (data.success) {
      messageDiv.innerHTML = `<strong style="color:green;">${data.success}</strong>`;
    } else if (data.error) {
      messageDiv.innerHTML = `<strong style="color:red;">${data.error}</strong>`;
    }
  })
  .catch(() => alert('Failed to update details'));
});
</script>
