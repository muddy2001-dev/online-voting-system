<?php
include_once __DIR__ . '/../admin/database.php';


$response = [];

$id        = intval($_POST['id'] ?? 0);
$name      = trim($_POST['name'] ?? '');
$regno     = trim($_POST['regno'] ?? '');
$phone     = trim($_POST['phone'] ?? '');
$gender    = trim($_POST['gender'] ?? '');
$dob       = trim($_POST['dob'] ?? '');
$created_at= trim($_POST['created_at'] ?? '');
$position  = trim($_POST['position'] ?? '');

// Photo upload
$photoPath = "";
if (!empty($_FILES['photo']['name'])) {
    $targetDir = "../uploads/";
    if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

    $photoPath = $targetDir . time() . "_" . basename($_FILES['photo']['name']);
    move_uploaded_file($_FILES['photo']['tmp_name'], $photoPath);
}

if ($id <= 0 || empty($name) || empty($regno) || empty($phone) || empty($gender) || empty($dob) || empty($created_at) || empty($position)) {
    $response['error'] = "All fields are required.";
} else {
    if ($photoPath) {
        // Update with new photo
        $stmt = $conn->prepare("UPDATE candidates 
            SET name=?, position=?, photo=?, regno=?, phone=?, gender=?, dob=?, created_at=? 
            WHERE id=?");
        $stmt->bind_param("ssssssssi", $name, $position, $photoPath, $regno, $phone, $gender, $dob, $created_at, $id);
    } else {
        // Update without changing photo
        $stmt = $conn->prepare("UPDATE candidates 
            SET name=?, position=?, regno=?, phone=?, gender=?, dob=?, created_at=? 
            WHERE id=?");
        $stmt->bind_param("sssssssi", $name, $position, $regno, $phone, $gender, $dob, $created_at, $id);
    }

    if ($stmt->execute()) {
        $response['success'] = "Candidate updated successfully.";
    } else {
        $response['error'] = "Failed to update Candidate.";
    }
    $stmt->close();
}

$conn->close();
echo json_encode($response);
?>
