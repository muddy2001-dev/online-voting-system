
<?php
  include_once __DIR__ . '/../admin/database.php';
session_name("voter_session");
session_start();

if (!isset($_SESSION['voter_id'])) {
    header("Location: voter-login.php");
    exit();
}

// Normalize ID variable
$userId = $_SESSION['voter']['id'] ?? $_SESSION['voter_id'];


$name = $email = $phone = "";

// Fetch user data
$stmt = $conn->prepare("SELECT name, regno, phone, gender, dob, created_at FROM voters WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$student = $result->fetch_assoc(); // assign to $student
$name = $student['name'];
$regno = $student['regno'];
$phone = $student['phone'];
$gender = $student['gender'];
$dob = $student['dob'];
$created_at = $student['created_at'];

$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Details</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f0f2f5;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 450px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: 500;
        }

        input[type="text"], input[type="email"], input[type="number"] {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            margin-top: 5px;
            border: 1px solid #ccc;
            background-color: #f9f9f9;
        }

        input[readonly] {
            background-color: #e9ecef;
            cursor: not-allowed;
        }

             .navbar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    background-color: #2c3e50;
    color: white;
    display: flex;
    justify-content: space-between;
    padding: 5px 10px;
    align-items: center;
    z-index: 1000; /* ensures it stays above everything */
    box-shadow: 0 2px 6px rgba(0,0,0,0.2);
}

        .navbar .logo {
            font-size: 20px;
            font-weight: bold;
        }

        .navbar .nav-links a {
            color: white;
            margin-left: 15px;
            text-decoration: none;
        }

        .navbar .nav-links a:hover {
            text-decoration: underline;
        }

        @media (max-width: 500px) {
            .container {
                margin: 20px;
                padding: 20px;
            }
        }
    </style>
  
</head>
<body>
    <nav class="navbar">
        <div class="logo">OVS</div>
        <div class="nav-links">
             <button onclick="window.location.href='voter.php'" style="border-radius: 10px; padding: 8px 16px; background-color: white; color: black; border: none; cursor: pointer;">
  Home
   </button>
            
        </div>
    </nav>

    <div class="container">
        <h2>Your Details</h2>

        <label>Full name</label>
        <input type="text" value="<?= htmlspecialchars($name) ?>" readonly>

        <label>Registration Number</label>
        <input type="text" value="<?= htmlspecialchars($regno) ?>" readonly>

        <label>Phone</label>
        <input type="number" value="<?= htmlspecialchars($phone) ?>" readonly>

         <label>Gender</label>
        <input type="text" value="<?= htmlspecialchars($gender) ?>" readonly>

       

          <label>Date Of Birth</label>
        <input type="text" value="<?= htmlspecialchars($dob) ?>" readonly>

          <label>Registered Date</label>
        <input type="text" value="<?= htmlspecialchars($created_at) ?>" readonly>
    </div>
</body>
</html>
t