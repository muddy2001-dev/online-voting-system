<?php
session_name("voter_session");
session_start();
$errors = ['regno' => '', 'dob' => ''];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
   include_once __DIR__ . '/../admin/database.php';

    $regno = trim($_POST['regno']);
    $dob = trim($_POST['dob']);

    if (empty($regno)) {
        $errors['regno'] = "Enter a valid registration number.";
    }

    if (empty($errors['regno'])) {
        // Use voters table
        $stmt = $conn->prepare("SELECT * FROM voters WHERE regno = ?");
        $stmt->bind_param("s", $regno);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows === 1) {
            $voter = $res->fetch_assoc();

            // Convert input date to match DB format (YYYY-MM-DD)
            $dobFormatted = date('Y-m-d', strtotime($dob));

            if ($dobFormatted === $voter['dob']) {
                $_SESSION['voter'] = $voter;
                $_SESSION['voter_id'] = $voter['id'];
                $_SESSION['regno'] = $voter['regno'];
                $_SESSION['voters_name'] = $voter['name']; 

                header("Location: voter.php");
                exit();
            } else {
                $errors['dob'] = "Incorrect date of birth.";
            }
        } else {
            $errors['regno'] = "No voter account found with that registration number.";
        }

        $stmt->close();
    }

    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Voter Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f2f5f7;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color:#2c3e50;
            color: white;
            display: flex;
            justify-content: space-between;
            padding: 5px 10px;
            align-items: center;
        }
        .navbar .logo { font-size: 20px; font-weight: bold; }
        .navbar .nav-links a {
            color: white;
            margin-left: 15px;
            text-decoration: none;
        }
        .form-container {
            max-width: 400px;
            background: white;
            padding: 30px;
            margin: 40px auto;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        .login-form h2 { text-align: center; margin-bottom: 25px; color: #333; }
        label { display: block; margin: 12px 0 6px; font-weight: 500; }
        input[type="text"], input[type="date"] {
            width: 100%; padding: 10px; border-radius: 5px; border: 1px solid #ccc;
        }
        .error {
            color: red; font-size: 14px; margin-top: 5px; margin-bottom: -5px;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #2c3e50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top:7px;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .forgot-password { margin-top: 15px; text-align: right; }
        .forgot-password a {
            color: #007bff; text-decoration: none;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">OVS</div>
        <div class="nav-links">
           
        </div>
    </nav>

    <div class="form-container">
        <form method="POST" class="login-form">
            <h2>Voter Login Form</h2>

            <label>Registration Number:</label>
            <input type="text" name="regno" placeholder="(e.g WSS-20XX-XXXXX)" value="<?= htmlspecialchars($_POST['regno'] ?? '') ?>" required>
            <p class="error"><?= $errors['regno'] ?></p>

            <label>Date Of Birth:</label>
            <input type="date" name="dob" required>
            <p class="error"><?= $errors['dob'] ?></p>

            <input type="submit" value="Send">

            <div class="forgot-password">
                <a href="contact.php">Forgot Registration Number?</a>
            </div>
        </form>
    </div>
</body>
</html>

