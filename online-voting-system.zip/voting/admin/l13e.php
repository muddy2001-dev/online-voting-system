<?php
session_start();
include 'database.php';

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $otp = $_POST["otp"];

    // Check OTP and not expired (5 minutes = 300 seconds)
    $sql = "SELECT id FROM admin 
            WHERE otp = ? 
            AND TIMESTAMPDIFF(SECOND, otp_generated_time, NOW()) <= 300";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $otp);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $row = $result->fetch_assoc();

        // ✅ Store admin id in session
        $_SESSION['admin'] = [
            'id' => $row['id'],
        ];
        $_SESSION['otp_verified'] = true;

        header('Location: delete_admin_account.php');
        exit();
    } else {
        echo '❌ Wrong OTP or OTP has expired.';
    }
}
$conn->close();
?>
