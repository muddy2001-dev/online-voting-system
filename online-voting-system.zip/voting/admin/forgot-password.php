<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <style>
      body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f2f5f7;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color:#2c3e50;
            color: white;
            display: flex;
            justify-content: space-between;
            padding: 5px 10px;
            align-items: center;
        }
        .navbar .nav-links button {
            background: #3498db;
            border: none;
            padding: 5px 10px;
            color: #fff;
            cursor: pointer;
        }
        .container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        h3 {
            text-align: center;
            color: #333;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }
        input[type="email"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #2c3e50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .signup-link {
            display: block;
            text-align: center;
            font-weight: bold;
            margin-top: 10px;
            text-decoration: none;
        }
        .signup-link a {
            color: blue;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <nav class="navbar">
  <div class="logo">OVS</div>
  <div class="nav-links">
    <button onclick="window.history.back()">Back</button>
  </div>
</nav>
    <div class="container">
        <h3>Enter Your Email</h3>
        <form method="post" action="l7c.php">
            <label for="email">Email:</label>
            <input type="email" name="email" required><br>

            <input type="submit" value="Send">
            
        </form>
    </div>
</body>
</html>


