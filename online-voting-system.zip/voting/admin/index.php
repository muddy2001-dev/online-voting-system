<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ajax Sidebar Layout</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

  <!-- Header -->
  <div class="header">
    <?php include_once 'header.php'; ?>
  </div>

  <!-- Sidebar + Content Layout -->
  <div class="main-layout">
    <!-- Sidebar -->
    <div class="sidebar">
      <h2><i class="fas fa-bars"></i> Menu</h2>
      <ul>
        
        <!-- Student Classes Accordion -->
        <li class="accordion-item">
          <a href="#" onclick="toggleAccordion('accordionClasses')"><i class="fas fa-school"></i> Voters</a>
          <ul class="accordion-content" id="accordionClasses">
            <li><a href="#" onclick="loadPage('voter.php')">Add Voter</a></li>
            <li><a href="#" onclick="loadPage('manage_voter.php')">Manage Voters</a></li>

            
          </ul>
        </li>

        <!-- Subjects Accordion -->
        <li class="accordion-item">
          <a href="#" onclick="toggleAccordion('accordionSubjects')"><i class="fas fa-book"></i> Candidates</a>
          <ul class="accordion-content" id="accordionSubjects">
            <li><a href="#" onclick="loadPage('candidate.php')">Add Candidate</a></li>
            <li><a href="#" onclick="loadPage('manage_candidate.php')">Manage Candidates</a></li>
          </ul>
        </li>
           <!-- Results Accordion -->
        <li class="accordion-item">
          <a href="#" onclick="toggleAccordion('accordionResults')"><i class="fas fa-book"></i> Results</a>
          <ul class="accordion-content" id="accordionResults">
            <li><a href="#" onclick="loadPage('manage_voting.php')">Add Results</a></li>
            <li><a href="#" onclick="loadPage('.php')">Manage Results</a></li>
          </ul>
        </li>
          <!-- Notices Accordion -->
        <li class="accordion-item">
          <a href="#" onclick="toggleAccordion('accordionNotices')"><i class="fas fa-book"></i> Notices</a>
          <ul class="accordion-content" id="accordionNotices">
            <li><a href="#" onclick="loadPage('faq.php')">Voters Notice</a></li>
            <li><a href="#" onclick="loadPage('manage_notice.php')">Manage Notices</a></li>
          </ul>
        </li>

        <!-- Direct Links -->
        <li><a href="#" onclick="loadPage('update.php')"><i class="fas fa-info-circle"></i> Settings</a></li>
         <li><a href="#" onclick="loadPage('index.php')"><i class="fas fa-info-circle"></i> Home</a></li>
      </ul>
    </div>

    <!-- Content -->
    <div class="content" id="mainContent">
    <h3> <marquee>Welcome To Online Voting System</marquee></h3>

    <div class="dashboard-cards">
     
             <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_voters.php')">
               <div class="card">
                <div class="card-logo">📝</div>
                <strong>Registered Voters</strong>
            </div>
             </a>
               <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_candidate.php')">
               <div class="card">
                <div class="card-logo">🗓️</div>
                <strong>Registered Candidates</strong>
            </div>
             </a>

           <a href="javascript:void(0);" class="card-link" onclick="loadPage('view_results.php')">
               <div class="card">
                <div class="card-logo">🗓️</div>
                <strong>Voting Results</strong>
            </div>
             </a>

        <a href="" class="card-link">
            <div class="card">
                <div class="card-logo">💳</div>
                <strong> Reports</strong>
            </div>
        </a>

     
    </div>
  </div>

<script>
// Load any page via AJAX
function loadPage(page) {
  fetch("../ajax/" + page) 
    .then(res => res.text())
    .then(html => {
      const mainContent = document.getElementById("mainContent");
      mainContent.innerHTML = html;



//Attach AJAX form handler based on the page

// (X) Manage voting (admin)
if (page.startsWith("manage_voting.php")) {
    document.addEventListener("submit", function (e) {
        if (e.target && e.target.id === "manageVotingForm") {
            e.preventDefault();
            const form = e.target;
            const formData = new FormData(form);
            fetch("../ajax/manage_voting.php", {
                method: "POST",
                body: formData
            })
            .then(res => res.text())
            .then(html => {
                document.getElementById("mainContent").innerHTML = html;
            });
        }
    }, { once: true });
}



// (number X) Handle update.php
if (page.startsWith('update.php')) {
    const form = document.getElementById('updateForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();

            const formData = new FormData(form);

            fetch('../ajax/update.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                const messageDiv = document.querySelector('.message');
                if (data.success) {
                    messageDiv.innerHTML = `<strong style="color:green;">${data.success}</strong>`;
                } else if (data.error) {
                    messageDiv.innerHTML = `<strong style="color:red;">${data.error}</strong>`;
                }
            })
            .catch(() => alert('Failed to update details'));
        });
    }

    // Make sure "Change Password" link works with loadPage
    document.querySelectorAll('.settings-options a').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const href = this.getAttribute('onclick') || this.getAttribute('href');
            if (href.includes('loadPage')) {
                // already calls loadPage
            } else if (href.endsWith('.php')) {
                loadPage(href);
            }
        });
    });
}


        //( number 2 ) Attach AJAX form handler based on the page
      if(page === 'candidate.php') {
        const form = document.getElementById('faqForm');
        if(form) {
          form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('../ajax/candidate.php', {
              method: 'POST',
              body: formData
            })
            .then(res => res.json())
            .then(data => {
              const responseDiv = document.getElementById('responseMessage');
              if(data.success) {
                responseDiv.innerHTML = `<div class="msg">${data.success}</div>`;
                form.reset();
              } else if(data.error) {
                responseDiv.innerHTML = `<div class="err">${data.error}</div>`;
              }
            })
            .catch(() => alert('Failed to submit form'));
          });
        }
      }

        //( number 2 ) Attach AJAX form handler based on the page
      if(page === 'voter.php') {
        const form = document.getElementById('faqForm');
        if(form) {
          form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('../ajax/voter.php', {
              method: 'POST',
              body: formData
            })
            .then(res => res.json())
            .then(data => {
              const responseDiv = document.getElementById('responseMessage');
              if(data.success) {
                responseDiv.innerHTML = `<div class="msg">${data.success}</div>`;
                form.reset();
              } else if(data.error) {
                responseDiv.innerHTML = `<div class="err">${data.error}</div>`;
              }
            })
            .catch(() => alert('Failed to submit form'));
          });
        }
      }
      



//( number 3 ) change password
      if(page === 'change_password.php') {
    const form = document.getElementById('changePasswordForm');
    const newFields = document.getElementById('newPasswordFields');

    if(form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('../ajax/change_password.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                const responseDiv = document.getElementById('responseMessage');
                if(data.show_new){
                    newFields.style.display = 'block';
                    responseDiv.innerHTML = '';
                    form.querySelector('input[type=submit]').value = 'Update Password';
                } else if(data.success){
                    responseDiv.innerHTML = `<div style="color:green;">${data.success}</div>`;
                    form.reset();
                    newFields.style.display = 'none';
                    form.querySelector('input[type=submit]').value = 'Verify Current Password';
                } else if(data.error){
                    responseDiv.innerHTML = `<div style="color:red;">${data.error}</div>`;
                }
            })
            .catch(() => alert('Failed to submit form'));
        });
    }
}

      //( number 1 ) manage notice
      if(page === 'faq.php') {
        const form = document.getElementById('faqForm');
        if(form) {
          form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('../ajax/faq.php', {
              method: 'POST',
              body: formData
            })
            .then(res => res.json())
            .then(data => {
              const responseDiv = document.getElementById('responseMessage');
              if(data.success) {
                responseDiv.innerHTML = `<div class="msg">${data.success}</div>`;
                form.reset();
              } else if(data.error) {
                responseDiv.innerHTML = `<div class="err">${data.error}</div>`;
              }
            })
            .catch(() => alert('Failed to submit form'));
          });
        }
      }


        //( number 6 ) edit and delete action in notice
      if (page.startsWith('edit_notice.php')) {
    const form = document.getElementById('editNoticeForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('../ajax/update_notice.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                const msg = document.getElementById('editResponse');
                if (data.success) {
                    msg.innerHTML = `<span style='color:green;'>${data.success}</span>`;
                    setTimeout(() => loadPage('manage_notice.php'), 800);
                } else if (data.error) {
                    msg.innerHTML = `<span style='color:red;'>${data.error}</span>`;
                }
            })
            .catch(() => alert('Error updating student'));
        });
    }
}

if (page === 'manage_notice.php') {
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            if (confirm('Are you sure you want to delete this notice?')) {
                const id = this.getAttribute('data-id');
                fetch(`../ajax/delete_notice.php?id=${id}`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            loadPage('manage_notice.php');
                        } else {
                            alert(data.error || 'Failed to delete notice');
                        }
                    });
            }
        });
    });

    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            loadPage(`edit_notice.php?id=${id}`);
        });
    });
}

      
       //( number 6 ) edit and delete action in patients
      if (page.startsWith('edit_voter.php')) {
    const form = document.getElementById('editVoterForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('../ajax/update_voter.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                const msg = document.getElementById('editResponse');
                if (data.success) {
                    msg.innerHTML = `<span style='color:green;'>${data.success}</span>`;
                    setTimeout(() => loadPage('manage_voter.php'), 800);
                } else if (data.error) {
                    msg.innerHTML = `<span style='color:red;'>${data.error}</span>`;
                }
            })
            .catch(() => alert('Error updating voter'));
        });
    }
}

if (page === 'manage_voter.php') {
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            if (confirm('Are you sure you want to delete this voter?')) {
                const id = this.getAttribute('data-id');
                fetch(`../ajax/delete_voter.php?id=${id}`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            loadPage('manage_voter.php');
                        } else {
                            alert(data.error || 'Failed to delete voter');
                        }
                    });
            }
        });
    });

    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            loadPage(`edit_voter.php?id=${id}`);
        });
    });
}

 //( number 6 ) edit and delete action in candidates
      if (page.startsWith('edit_candidate.php')) {
    const form = document.getElementById('editCandidateForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(form);

            fetch('../ajax/update_candidate.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                const msg = document.getElementById('editResponse');
                if (data.success) {
                    msg.innerHTML = `<span style='color:green;'>${data.success}</span>`;
                    setTimeout(() => loadPage('manage_candidate.php'), 800);
                } else if (data.error) {
                    msg.innerHTML = `<span style='color:red;'>${data.error}</span>`;
                }
            })
            .catch(() => alert('Error updating candidate'));
        });
    }
}

if (page === 'manage_candidate.php') {
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            if (confirm('Are you sure you want to delete this candidate?')) {
                const id = this.getAttribute('data-id');
                fetch(`../ajax/delete_candidate.php?id=${id}`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            loadPage('manage_candidate.php');
                        } else {
                            alert(data.error || 'Failed to delete candidate');
                        }
                    });
            }
        });
    });

    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            loadPage(`edit_candidate.php?id=${id}`);
        });
    });
}





      // Attach handlers if dep.php
      if (page === 'dep.php') attachDepHandlers();
    })
    .catch(() => {
      document.getElementById("mainContent").innerHTML = "<p>Error loading page.</p>";
    });
}

// Department page handlers
function attachDepHandlers() {
  const responseDiv = document.getElementById('responseMessage');

  // --- Add Department ---
  const deptForm = document.getElementById('addDeptForm');
  if (deptForm) {
    deptForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const formData = new FormData(deptForm);

      fetch('ajax/dep.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          responseDiv.innerHTML = `<div class="msg">${data.success}</div>`;
          deptForm.reset();
          loadPage('dep.php'); // reload table
        } else if (data.error) {
          responseDiv.innerHTML = `<div class="err">${data.error}</div>`;
        }
      })
      .catch(() => alert('Failed to add department'));
    });
  }

  // --- Load Slots when selecting department ---
  const deptSelect = document.getElementById('departmentSelect');
  if (deptSelect) {
    deptSelect.addEventListener('change', function() {
      const formData = new FormData();
      formData.append('department_id', this.value);

      fetch('ajax/load_slots.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.text())
      .then(html => {
        document.getElementById('slotsContainer').innerHTML = html;

        // Now reattach Save Slots handler
        attachSlotFormHandler();
      })
      .catch(err => console.error("Failed to load slots:", err));
    });
  }

  // --- Delete Department ---
  document.querySelectorAll('.deleteDeptBtn').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      if (!confirm("Delete this department?")) return;

      fetch('ajax/dep.php', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: 'delete_id=' + this.dataset.id
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          responseDiv.innerHTML = `<div class="msg">${data.success}</div>`;
          loadPage('dep.php'); // reload table
        }
      })
      .catch(() => alert('Failed to delete department'));
    });
  });

  // Attach slot form if already rendered
  attachSlotFormHandler();
}


// Separate function for saving slots
function attachSlotFormHandler() {
  const slotForm = document.getElementById('slotForm');
  if (slotForm) {
    slotForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const formData = new FormData(slotForm);

      fetch('ajax/dep.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.json())
      .then(data => {
        // Select responseDiv inside the form
        const responseDiv = slotForm.querySelector('#slotResponseMessage');

        if (data.success) {
          responseDiv.innerHTML = `<div class="msg">${data.success}</div>`;

          // Optional: fade out after 3 seconds
          setTimeout(() => {
            responseDiv.innerHTML = '';
          }, 3000);

          // Reload slots for the selected department
          const deptSelect = document.getElementById('departmentSelect');
          if (deptSelect && deptSelect.value) {
            const reloadData = new FormData();
            reloadData.append('department_id', deptSelect.value);

            fetch('ajax/load_slots.php', {
              method: 'POST',
              body: reloadData
            })
            .then(res => res.text())
            .then(html => {
              document.getElementById('slotsContainer').innerHTML = html;
              attachSlotFormHandler(); // reattach handler to the new form
            })
            .catch(err => console.error("Failed to reload slots:", err));
          }
        } else if (data.error) {
          responseDiv.innerHTML = `<div class="err">${data.error}</div>`;
        }
      })
      .catch(() => alert('Failed to save slots'));
    });
  }
}






// Accordion toggle
function toggleAccordion(id) {
  const accordions = document.querySelectorAll(".accordion-content");
  accordions.forEach(acc => {
    if (acc.id !== id) acc.style.display = "none";
  });
  const content = document.getElementById(id);
  if (content) content.style.display = (content.style.display === "block") ? "none" : "block";
}

// Logout
function confirmLogout() {
  if (confirm("Are you sure you want to logout?")) {
    window.location.href = "logout.php";
  }
}
</script>

</body>
</html>
