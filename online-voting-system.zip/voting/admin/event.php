<?php
include_once 'database.php';

// Fetch the latest notices (limit to 10 for performance)
$result = $conn->query("SELECT * FROM faqs ORDER BY created_at DESC LIMIT 10");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Upcoming Events</title>
    <style>
            body { font-family: 'Segoe UI', sans-serif; background-color: #f2f5f7; margin:0; padding:0; }
        .navbar { background-color:#2c3e50; color: white; display: flex; justify-content: space-between; padding: 5px 10px; align-items: center; }
        .navbar .logo { font-size: 20px; font-weight: bold; }
        .navbar .nav-links button { background: #3498db; border: none; padding: 5px 10px; color: #fff; cursor: pointer; }
        h2 {
            text-align: center;
            color: #333;
        }
        .event-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }
        .event-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            width: 300px;
            padding: 20px;
            transition: transform 0.2s ease;
        }
        .event-card:hover {
            transform: translateY(-5px);
        }
        .event-title {
            font-size: 1.2em;
            font-weight: bold;
            color: #0056b3;
            margin-bottom: 10px;
        }
        .event-message {
            font-size: 0.95em;
            color: #555;
            margin-bottom: 15px;
        }
        .event-date {
            font-size: 0.85em;
            color: #999;
            text-align: right;
        }
    </style>
</head>
<body>
<nav class="navbar">
    <div class="logo">SRMS</div>
    <div class="nav-links">
        <button onclick="window.history.back()">Back</button>
    </div>
</nav>
<h2>📅 Upcoming Events & Notices</h2>
<div class="event-container">
<?php while ($row = $result->fetch_assoc()): ?>
    <div class="event-card">
        <div class="event-title"><?php echo htmlspecialchars($row['tittle']); ?></div>
        <div class="event-message"><?php echo nl2br(htmlspecialchars($row['message'])); ?></div>
        <div class="event-date">🕒 <?php echo date("F j, Y", strtotime($row['created_at'])); ?></div>
    </div>
<?php endwhile; ?>
</div>

<?php $conn->close(); ?>
</body>
</html>
