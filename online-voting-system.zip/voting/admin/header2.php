<?php

session_start();
if (!isset($_SESSION['student_id'])) {
    // Not logged in, redirect to login page or show error
    header("Location: student-login.php");
    exit();
}
$initial = '?';

if (isset($_SESSION['students_name'])) {
    $initial = strtoupper(substr($_SESSION['students_name'], 0, 1));
} elseif (isset($_SESSION['name'])) {
    $initial = strtoupper(substr($_SESSION['name'], 0, 1));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
 <link rel="stylesheet" href="styles.css">
</head>
<body>
    
      
        <nav class="navbar">
              <div class="a">
            <p>Student Dashboard</p>
        </div>
           <div class="nav-links">
     <a href="notifications.php" title="Notifications" style="position: relative;">
  🔔
  <span id="notificationBadge"
        style="position: absolute; top: -5px; right: -5px; background: red; color: white; 
               border-radius: 50%; padding: 2px 6px; font-size: 12px; display: none;">
  </span>
</a>
      <div class="profile-dropdown">
    <a href="javascript:void(0);" class="profile-circle" id="profileBtn" title=""><?= $initial ?></a>
    <div class="dropdown-content" id="profileMenu">
     
        <a href="javascript:void(0);" onclick="confirmLogout()">Logout</a>

    </div>
</div>

        </nav>
      
    <script>document.addEventListener('DOMContentLoaded', function() {
    const profileBtn = document.getElementById('profileBtn');
    const profileMenu = document.getElementById('profileMenu');
    const profileDropdown = profileBtn.parentElement;

    profileBtn.addEventListener('click', function(e) {
        e.preventDefault();
        profileDropdown.classList.toggle('show');
    });

    // Close dropdown if clicking outside
    window.addEventListener('click', function(e) {
        if (!profileDropdown.contains(e.target)) {
            profileDropdown.classList.remove('show');
        }
    });
});
</script>
<script>
document.addEventListener("DOMContentLoaded", function () {
    fetch("get_unread_notifications.php")
        .then(response => response.json())
        .then(data => {
            const badge = document.getElementById("notificationBadge");
            if (data.count > 0) {
                badge.innerText = data.count;
                badge.style.display = "inline-block";
            } else {
                badge.style.display = "none";
            }
        })
        .catch(error => console.error("Error loading notifications:", error));
});
</script>
 <script>
function confirmLogout() {
    if (confirm("Are you sure you want to logout?")) {
        window.location.href = "logout.php";
    }
}
</script>
</body>
</html>