<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
         h2 {
      text-align: center;
      margin: 30px 0 10px;
      color: #333;
    }

    .dashboard-cards {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      max-width: 1000px;
      margin: 0 auto;
      gap: 35px;
      padding: 20px;
    }

    .card-link {
      flex: 1 1 calc(33% - 20px);
      text-decoration: none;
    }

  .card {
  background-color: white;
  border-radius: 10px;
  padding: 30px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
  text-align: center;
  transition: transform 0.2s;
  border: 1px solid #e0e0e0;
  min-height: 140px; /* <-- Add this line */
}


    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 6px 18px rgba(0,0,0,0.1);
    }

    .card strong {
      display: block;
      margin-top: 8px;
      font-size: 18px;
      color: #333;
    }

    .card-logo {
      font-size: 36px;
    }
   

    </style>
</head>
<body>
     <h2>Welcome to Your Dashboard</h2>

    <div class="dashboard-cards">
        <a href="payment_option.php" class="card-link">
            <div class="card">
                <div class="card-logo">📝</div>
                <strong>Book Appointment</strong>
            </div>
        </a>

        <a href="appointments.php" class="card-link">
            <div class="card">
                <div class="card-logo">🗓️</div>
                <strong>My Appointments</strong>
            </div>
        </a>

        <a href="payments.php" class="card-link">
            <div class="card">
                <div class="card-logo">💳</div>
                <strong>My Payments</strong>
            </div>
        </a>

        <a href="update.php" class="card-link">
            <div class="card">
                <div class="card-logo">⚙️</div>
                <strong>Settings</strong>
            </div>
        </a>
    </div>
</body>
</html>