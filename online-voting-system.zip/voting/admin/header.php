<?php
session_name("admin_session");
session_start();
if (!isset($_SESSION['admin_id'])) {
    // Not logged in, redirect to login page or show error
    header("Location: login.php");
    exit();
}
$initial = '?';

if (isset($_SESSION['user_email'])) {
    $initial = strtoupper(substr($_SESSION['user_email'], 0, 1));
} elseif (isset($_SESSION['email'])) {
    $initial = strtoupper(substr($_SESSION['email'], 0, 1));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
 <link rel="stylesheet" href="style.css">
</head>
<body>
    
      
        <nav class="navbar">
              <div class="a">
            <p>Admin Dashboard</p>
        </div>
      <div class="profile-dropdown">
    <a href="javascript:void(0);" class="profile-circle" id="profileBtn" title=""><?= $initial ?></a>
    <div class="dropdown-content" id="profileMenu">
       <a href="javascript:void(0);" onclick="loadPage('views.php')">My Details</a>
        <a href="javascript:void(0);" onclick="confirmLogout()">Logout</a>
    </div>
</div>

        </nav>
      
    <script>document.addEventListener('DOMContentLoaded', function() {
    const profileBtn = document.getElementById('profileBtn');
    const profileMenu = document.getElementById('profileMenu');
    const profileDropdown = profileBtn.parentElement;

    profileBtn.addEventListener('click', function(e) {
        e.preventDefault();
        profileDropdown.classList.toggle('show');
    });

    // Close dropdown if clicking outside
    window.addEventListener('click', function(e) {
        if (!profileDropdown.contains(e.target)) {
            profileDropdown.classList.remove('show');
        }
    });
});
</script>
</body>
</html>